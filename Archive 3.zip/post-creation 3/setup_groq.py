#!/usr/bin/env python3
"""
Groq API Key Setup Helper

This script helps you get started with Groq's free API.
"""

def print_groq_setup_instructions():
    print("🚀 GROQ API SETUP (FREE) 🚀")
    print("="*50)
    print()
    print("Groq offers FREE API access with generous limits!")
    print()
    print("📋 Steps to get your Groq API key:")
    print("1. Go to: https://console.groq.com/")
    print("2. Sign up for a free account")
    print("3. Navigate to 'API Keys' section")
    print("4. Click 'Create API Key'")
    print("5. Copy your API key")
    print("6. Add it to your .env file:")
    print("   GROQ_API_KEY=your_actual_groq_api_key_here")
    print()
    print("💡 Groq Features:")
    print("   ✅ Free tier with generous limits")
    print("   ✅ Fast inference speed")
    print("   ✅ Access to Llama 3 models")
    print("   ✅ No credit card required")
    print()
    print("🔄 Alternative: OpenAI (Premium)")
    print("   - Get API key from: https://platform.openai.com/api-keys")
    print("   - Add to .env: OPENAI_API_KEY=your_openai_key")
    print("   - Set use_openai=True in main.py")
    print()
    print("🎯 Current .env file should look like:")
    print("GROQ_API_KEY=gsk_...")
    print("LINKEDIN_EMAIL=your_email@example.com")
    print("LINKEDIN_PASSWORD=your_password")
    print()

if __name__ == "__main__":
    print_groq_setup_instructions()
