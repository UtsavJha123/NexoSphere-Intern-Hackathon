from selenium_helper import get_top_google_trend_today
from ai_helper import create_new_prompt, chat_with_ai
from datetime import datetime
import os


def generate_daily_post(use_openai=False):
    """
    Generate a daily LinkedIn post from trending topics
    
    Args:
        use_openai (bool): Whether to use OpenAI instead of Groq (default: False for free option)
    """
    try:
        print("� Trending Post Generator (Free Version with Groq)")
        print("="*50)
        print("�🔍 Fetching top trending topic...")
        top_trend = get_top_google_trend_today()
        if not top_trend:
            print("❌ No real trends found, using fallback...")
            from trend_fallback import get_sample_trend
            top_trend = get_sample_trend()

        print(f"📈 Found trending topic: {top_trend['subject']}")
        
        date = datetime.now().date()
        prompt_content = create_new_prompt(top_trend["content"])
        
        print("🤖 Generating LinkedIn post...")
        linkedin_post = chat_with_ai(prompt_content, use_openai=use_openai)
        
        if linkedin_post and isinstance(linkedin_post, str):
            # Create output directory
            os.makedirs('./linkedin-posts', exist_ok=True)
            
            # Clean filename
            safe_subject = "".join(c for c in top_trend['subject'] if c.isalnum() or c in (' ', '-', '_')).rstrip()
            filename = f"./linkedin-posts/{safe_subject.replace(' ', '_')[:50]}_{date}.txt"
            
            with open(filename, "w", encoding="utf-8") as file:
                file.write(linkedin_post)
            print(f"✅ Post generated successfully and saved to: {filename}")
            print("\n" + "="*60)
            print("🎯 GENERATED LINKEDIN POST:")
            print("="*60)
            print(linkedin_post)
            print("="*60)
            print(f"\n💡 Generated using {'OpenAI (Premium)' if use_openai else 'Groq (Free)'} API")
        else:
            print("❌ Failed to generate post content")
            
    except Exception as e:
        print(f"❌ Error: Process incomplete - {e}")
        print(f"❌ Error: Process incomplete - {e}")


if __name__ == "__main__":
    print("🚀 Trending Post Generator (Free Version with Groq)")
    print("="*50)
    
    # Use Groq by default (free), set to True to use OpenAI (premium)
    generate_daily_post(use_openai=False)
