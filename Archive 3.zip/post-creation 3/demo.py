#!/usr/bin/env python3
"""
Demo script - Generate a LinkedIn post without web scraping
Perfect for testing the AI integration
"""

from ai_helper import create_new_prompt, chat_with_ai
from datetime import datetime
import os

def demo_post_generation():
    """Generate a demo post using a sample trending topic"""
    
    print("🎭 DEMO MODE: Trending Post Generator")
    print("="*50)
    
    # Sample trending topic data
    sample_trend = {
        "subject": "AI Workplace Integration 2024",
        "content": """
        Artificial Intelligence is rapidly transforming the modern workplace. Recent studies show that 73% of companies are planning to integrate AI tools into their daily operations within the next 12 months. 
        
        Key findings include:
        - 45% increase in productivity when AI tools are properly implemented
        - Workers spend 30% less time on repetitive tasks
        - New job roles emerging in AI prompt engineering and AI training
        - Companies investing $2.8 billion in workplace AI solutions
        
        The shift is happening faster than expected, with remote work accelerating adoption. However, experts warn about the need for proper training and ethical AI implementation.
        
        Industry leaders suggest that the key to successful AI integration is not replacing human workers, but augmenting human capabilities and creativity.
        """
    }
    
    try:
        print(f"📈 Demo trending topic: {sample_trend['subject']}")
        print("🤖 Generating LinkedIn post with AI...")
        
        # Create prompt
        prompt_content = create_new_prompt(sample_trend["content"])
        
        # Generate post (try Groq first, fallback to OpenAI)
        linkedin_post = chat_with_ai(prompt_content, use_openai=False)
        
        if linkedin_post and isinstance(linkedin_post, str):
            # Save the post
            date = datetime.now().date()
            filename = f"./linkedin-posts/DEMO_{sample_trend['subject'].replace(' ', '_')}_{date}.txt"
            
            # Create directory if it doesn't exist
            os.makedirs('./linkedin-posts', exist_ok=True)
            
            with open(filename, "w", encoding="utf-8") as file:
                file.write(linkedin_post)
            
            print(f"✅ Demo post generated successfully!")
            print(f"💾 Saved to: {filename}")
            print("\n" + "="*60)
            print("🎯 GENERATED LINKEDIN POST:")
            print("="*60)
            print(linkedin_post)
            print("="*60)
            print("\n💡 This was generated using FREE Groq API!")
            print("🚀 Ready to generate posts from real trending topics!")
        else:
            print("❌ Failed to generate demo post")
            print("💡 Check your API key configuration:")
            print("   1. Run: python setup_groq.py")
            print("   2. Get your free Groq API key")  
            print("   3. Update .env file")
            
    except Exception as e:
        print(f"❌ Demo failed: {e}")
        print("🔧 Troubleshooting:")
        print("   1. Ensure virtual environment is activated")
        print("   2. Check .env file configuration")
        print("   3. Test with: python test_ai.py")

def main():
    print("🎯 Choose an option:")
    print("1. Run demo (no web scraping)")
    print("2. Test AI integration only")
    print("3. Exit")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == "1":
        demo_post_generation()
    elif choice == "2":
        from test_ai import test_ai_integration
        test_ai_integration()
    elif choice == "3":
        print("👋 Goodbye!")
    else:
        print("❌ Invalid choice")

if __name__ == "__main__":
    main()
