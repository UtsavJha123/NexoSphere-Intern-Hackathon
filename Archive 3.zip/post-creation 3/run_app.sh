#!/bin/bash

# LinkedIn Post Generator Assistant - Unified Setup Script
echo "🚀 Setting up LinkedIn Post Generator Assistant..."

# Check if virtual environment exists
if [ ! -d ".venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source .venv/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "⚙️  Creating .env file from example..."
    cp .env.example .env
    echo "📝 Please edit .env file with your API keys!"
else
    echo "✅ .env file already exists"
fi

echo "✅ Setup complete!"
echo ""
echo "🎯 To run the application:"
echo "   source .venv/bin/activate"
echo "   streamlit run app.py"
echo ""
echo "📋 Make sure to configure your API keys in .env file:"
echo "   - GROQ_API_KEY (required)"
echo "   - OPENAI_API_KEY (optional, for premium features)"
echo "   - LINKEDIN_EMAIL (optional, for future LinkedIn automation)"
echo "   - LINKEDIN_PASSWORD (optional, for future LinkedIn automation)"
