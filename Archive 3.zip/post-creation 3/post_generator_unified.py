from ai_helper import chat_with_ai
from few_shot_helper import FewShotPosts

# Create a global instance to avoid reloading data
_few_shot_instance = None

def get_few_shot_instance():
    """Get or create FewShotPosts instance"""
    global _few_shot_instance
    if _few_shot_instance is None:
        _few_shot_instance = FewShotPosts()
    return _few_shot_instance


def get_length_str(length):
    if length == "Short":
        return "1 to 5 lines"
    if length == "Medium":
        return "6 to 10 lines"
    if length == "Long":
        return "11 to 15 lines"


def generate_style_post(length, language, tag, use_openai=False):
    """
    Generate a LinkedIn post using few-shot learning approach
    
    Args:
        length (str): Post length - Short, Medium, or Long
        language (str): Language - English or Hinglish
        tag (str): Topic/tag for the post
        use_openai (bool): Whether to use OpenAI instead of Groq
    
    Returns:
        str: Generated post content
    """
    prompt = get_prompt(length, language, tag)
    response = chat_with_ai(prompt, use_openai=use_openai)
    return response


def get_prompt(length, language, tag):
    length_str = get_length_str(length)

    prompt = f'''
Generate a LinkedIn post using the below information. No preamble.

1) Topic: {tag}
2) Length: {length_str}
3) Language: {language}
If Language is Hinglish then it means it is a mix of Hindi and English. 
The script for the generated post should always be English.
'''

    few_shot = get_few_shot_instance()
    examples = few_shot.get_filtered_posts(length, language, tag)

    if len(examples) > 0:
        prompt += "4) Use the writing style as per the following examples:"

    for i, post in enumerate(examples):
        post_text = post['text']
        prompt += f"\n\nExample {i+1}:\n{post_text}"
        if i >= 2:  # Limit to 3 examples max
            break

    # If no examples found, add general guidance
    if len(examples) == 0:
        prompt += """
4) Follow these LinkedIn best practices:
   - Start with an engaging hook
   - Use short paragraphs for readability
   - Include relevant emojis sparingly
   - End with a call-to-action or question
   - Keep the tone professional yet conversational
"""

    prompt += f"\n\nNow generate a {length.lower()} LinkedIn post about '{tag}' in {language}."
    
    return prompt


if __name__ == "__main__":
    # Test the function
    post = generate_style_post("Medium", "English", "Technology")
    print("Generated Post:")
    print(post)
