"""
Alternative trend fetcher that uses mock data when web scraping fails.
This ensures the application always works even if Google Trends structure changes.
"""

import random
from datetime import datetime

# Sample trending topics to use when web scraping fails
SAMPLE_TRENDS = [
    {
        "subject": "AI Revolution in Healthcare 2024",
        "content": "Artificial Intelligence is transforming healthcare with breakthrough diagnostic tools achieving 95% accuracy in early disease detection. Major hospitals are implementing AI-powered systems for patient care, drug discovery, and treatment optimization. The healthcare AI market is projected to reach $45 billion by 2026, creating new job opportunities in medical AI specialization.",
        "search_count": 850000
    },
    {
        "subject": "Remote Work Technology Trends",
        "content": "The latest survey reveals that 78% of companies are investing in advanced remote work technologies. Virtual reality meetings, AI-powered collaboration tools, and cloud-based project management systems are becoming standard. This shift is creating opportunities for tech professionals specializing in remote work solutions and digital workplace optimization.",
        "search_count": 650000
    },
    {
        "subject": "Sustainable Technology Innovation",
        "content": "Green technology investments have reached record highs with $290 billion in funding this year. Solar energy efficiency has improved by 40%, electric vehicle adoption is accelerating, and sustainable manufacturing processes are being implemented across industries. This trend is creating thousands of jobs in clean technology sectors.",
        "search_count": 720000
    },
    {
        "subject": "Cybersecurity Skills Gap 2024",
        "content": "The cybersecurity industry faces a shortage of 3.5 million professionals globally. Companies are offering unprecedented salaries and benefits to attract talent. New roles in AI-powered security, quantum cryptography, and zero-trust architecture are emerging. Organizations are investing heavily in cybersecurity training and certification programs.",
        "search_count": 480000
    },
    {
        "subject": "Digital Marketing Evolution",
        "content": "Marketing professionals are adapting to cookieless advertising and AI-driven personalization. Programmatic advertising, influencer marketing platforms, and social commerce are reshaping the industry. Companies are seeking professionals skilled in data privacy, marketing automation, and cross-channel campaign management.",
        "search_count": 390000
    }
]

def get_sample_trend():
    """Get a random sample trend for testing purposes"""
    trend = random.choice(SAMPLE_TRENDS)
    print(f"📊 Using sample trend: {trend['subject']}")
    print(f"   📈 Sample search count: {trend['search_count']:,}")
    return trend

def get_trend_with_fallback():
    """
    Try to get real trends, fall back to sample data if needed
    """
    try:
        # Try to import and use the real scraping function
        from selenium_helper import get_top_google_trend_today
        print("🌐 Attempting to fetch real trending topics...")
        real_trend = get_top_google_trend_today()
        
        if real_trend:
            print("✅ Successfully fetched real trend!")
            return real_trend
        else:
            print("⚠️  No real trends found, using sample data...")
            return get_sample_trend()
            
    except Exception as e:
        print(f"⚠️  Web scraping failed ({e}), using sample data...")
        return get_sample_trend()
