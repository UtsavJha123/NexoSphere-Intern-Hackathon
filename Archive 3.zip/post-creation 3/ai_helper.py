from groq import Groq
from dotenv import load_dotenv
import os
load_dotenv()

# Try to import OpenAI for fallback
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False


def chat_with_ai(prompt, use_openai=False):
    """
    Generate content using AI - supports both Groq (free) and OpenAI (premium)
    
    Args:
        prompt (str): The prompt to send to the AI
        use_openai (bool): Whether to use OpenAI instead of Groq
    
    Returns:
        str: Generated content or None if failed
    """
    
    # Try Groq first (free option)
    if not use_openai:
        groq_result = _chat_with_groq(prompt)
        if groq_result:
            return groq_result
        print("Groq failed, trying OpenAI if available...")
    
    # Fallback to OpenAI if Groq fails or if explicitly requested
    if OPENAI_AVAILABLE:
        return _chat_with_openai(prompt)
    else:
        print("OpenAI not available. Please install with: pip install openai")
        return None


def _chat_with_groq(prompt):
    """Use Groq API (free option)"""
    print("Connecting to Groq (Free)...")
    try:
        groq_api_key = os.environ.get("GROQ_API_KEY")
        if not groq_api_key or groq_api_key == "your_groq_api_key_here":
            print("❌ GROQ_API_KEY not configured in .env file")
            return None
            
        client = Groq(api_key=groq_api_key)
        
        chat_completion = client.chat.completions.create(
            messages=[
                {
                    "role": "system",
                    "content": "You are a professional LinkedIn content creator. Create engaging, professional posts that drive engagement and provide value to the audience."
                },
                {
                    "role": "user", 
                    "content": prompt
                }
            ],
            model="llama3-8b-8192",  # Free tier model
            max_tokens=1000,
            temperature=0.7
        )
        
        return chat_completion.choices[0].message.content
        
    except Exception as e:
        print(f"Failed to interact with Groq: {e}")
        return None


def _chat_with_openai(prompt):
    """Use OpenAI API (premium option)"""
    print("Connecting to OpenAI (Premium)...")
    try:
        openai_api_key = os.environ.get("OPENAI_API_KEY")
        if not openai_api_key or openai_api_key == "your_openai_api_key_here":
            print("❌ OPENAI_API_KEY not configured in .env file")
            return None
            
        client = OpenAI(api_key=openai_api_key)
        gpt_response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a professional LinkedIn content creator. Create engaging, professional posts that drive engagement and provide value to the audience."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.7
        )
        return gpt_response.choices[0].message.content
        
    except Exception as e:
        print(f"Failed to interact with OpenAI: {e}")
        return None


def create_new_prompt(article_content):
    """Create a prompt combining base template with article content"""
    try:
        with open("base_linkedin_post_prompt.txt", "r", encoding="utf-8") as file:
            base_prompt = file.read()
        
        full_prompt = f"{base_prompt}\n\nArticle Content:\n{article_content}\n\nPlease create an engaging LinkedIn post based on this trending topic."
        return full_prompt
        
    except FileNotFoundError:
        print("❌ base_linkedin_post_prompt.txt not found")
        return f"Create a professional LinkedIn post about this trending topic:\n\n{article_content}"
    except Exception as e:
        print(f"Error reading prompt template: {e}")
        return f"Create a professional LinkedIn post about this trending topic:\n\n{article_content}"


# Backwards compatibility
def chat_with_gpt3(prompt):
    """Backwards compatibility function - now uses Groq by default"""
    return chat_with_ai(prompt, use_openai=False)
