#!/usr/bin/env python3
"""
Robust main script with fallback trending topics
"""

from ai_helper import create_new_prompt, chat_with_ai
from trend_fallback import get_trend_with_fallback
from datetime import datetime
import os

def generate_daily_post(use_openai=False, force_sample=False):
    """
    Generate a daily LinkedIn post from trending topics
    
    Args:
        use_openai (bool): Whether to use OpenAI instead of Groq (default: False for free option)
        force_sample (bool): Force use of sample data instead of web scraping
    """
    try:
        print("🚀 Trending Post Generator (Robust Free Version)")
        print("="*60)
        print("🔍 Fetching trending topic...")
        
        if force_sample:
            from trend_fallback import get_sample_trend
            top_trend = get_sample_trend()
        else:
            top_trend = get_trend_with_fallback()
            
        if not top_trend:
            print("❌ Error: Could not get any trending topic")
            return

        print(f"📈 Selected trending topic: {top_trend['subject']}")
        
        # Create the AI prompt
        print("📝 Creating AI prompt...")
        prompt_content = create_new_prompt(top_trend["content"])
        
        # Generate the LinkedIn post
        print("🤖 Generating LinkedIn post with AI...")
        linkedin_post = chat_with_ai(prompt_content, use_openai=use_openai)
        
        if linkedin_post and isinstance(linkedin_post, str):
            # Create output directory
            os.makedirs('./linkedin-posts', exist_ok=True)
            
            # Save the post
            date = datetime.now().date()
            safe_subject = "".join(c for c in top_trend['subject'] if c.isalnum() or c in (' ', '-', '_')).rstrip()
            filename = f"./linkedin-posts/{safe_subject.replace(' ', '_')}_{date}.txt"
            
            with open(filename, "w", encoding="utf-8") as file:
                file.write(linkedin_post)
            
            print(f"✅ Post generated successfully!")
            print(f"💾 Saved to: {filename}")
            print("\n" + "="*70)
            print("🎯 GENERATED LINKEDIN POST:")
            print("="*70)
            print(linkedin_post)
            print("="*70)
            print(f"\n💡 Generated using {'OpenAI (Premium)' if use_openai else 'Groq (Free)'} API")
            print("🚀 Your LinkedIn post is ready to share!")
            
        else:
            print("❌ Failed to generate post content")
            print("💡 Check your API key configuration in .env file")
            
    except Exception as e:
        print(f"❌ Error: {e}")
        print("\n🔧 Troubleshooting:")
        print("1. Check your .env file has GROQ_API_KEY configured")
        print("2. Ensure virtual environment is activated: source .venv/bin/activate")
        print("3. Test AI integration: python test_ai.py")

def main():
    """Main function with user options"""
    print("🎯 Choose generation mode:")
    print("1. Auto mode (try real trends, fallback to samples)")
    print("2. Sample mode (use sample trends only)")
    print("3. Force real trends (web scraping only)")
    print("4. Exit")
    
    try:
        choice = input("\nEnter choice (1-4): ").strip()
        
        if choice == "1":
            generate_daily_post(use_openai=False, force_sample=False)
        elif choice == "2":
            generate_daily_post(use_openai=False, force_sample=True)
        elif choice == "3":
            from selenium_helper import get_top_google_trend_today
            from ai_helper import create_new_prompt, chat_with_ai
            
            print("🌐 Forcing web scraping mode...")
            trend = get_top_google_trend_today()
            if trend:
                prompt = create_new_prompt(trend["content"])
                post = chat_with_ai(prompt, use_openai=False)
                if post:
                    print("✅ Success with real web scraping!")
                    print(post)
                else:
                    print("❌ AI generation failed")
            else:
                print("❌ Web scraping failed")
        elif choice == "4":
            print("👋 Goodbye!")
        else:
            print("❌ Invalid choice")
            
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
