#!/bin/bash

# Trending Post Generator Setup Script - FREE VERSION

echo "🚀 Setting up Trending Post Generator (FREE with Groq)..."

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed. Please install Python 3 first."
    exit 1
fi

# Create virtual environment if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source .venv/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install -r requirements.txt

# Create .env file from example if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📋 Creating .env file from template..."
    cp .env.example .env
    echo "⚠️  IMPORTANT: Edit .env file with your actual API keys!"
else
    echo "✅ .env file already exists"
fi

# Create linkedin-posts directory if it doesn't exist
if [ ! -d "linkedin-posts" ]; then
    echo "📁 Creating linkedin-posts directory..."
    mkdir -p linkedin-posts
fi

echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo "1. Get your FREE Groq API key:"
echo "   python setup_groq.py"
echo ""
echo "2. Edit .env file with your actual API key:"
echo "   GROQ_API_KEY=gsk_your_actual_groq_key"
echo ""
echo "3. Test the setup:"
echo "   source .venv/bin/activate"
echo "   python test_ai.py"
echo ""
echo "4. Generate your first post:"
echo "   python main.py"
echo ""
echo "💡 This FREE version uses Groq API (no credit card needed!)"
