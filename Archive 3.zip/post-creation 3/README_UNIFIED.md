# 🚀 LinkedIn Post Generator Assistant

A comprehensive AI-powered LinkedIn post generator that combines **trending topics** and **style-based generation** in one unified Streamlit application.

## ✨ Features

### 🔥 Trending Topics Mode
- **Live Google Trends Scraping**: Automatically fetches today's hottest trends
- **Groq Integration**: Free AI generation using Llama 3
- **OpenAI Support**: Premium option with GPT-3.5-turbo
- **Smart Fallback**: Sample trends when live scraping fails
- **Auto-Save**: Generated posts saved with timestamps

### 🎨 Style-Based Generation Mode  
- **Few-Shot Learning**: Learns from existing LinkedIn posts
- **Customizable Parameters**: Length (Short/Medium/Long), Language (English/Hinglish), Topics
- **Rich Topic Library**: Pre-processed posts with diverse topics
- **Custom Topics**: Generate posts on any topic you specify
- **Style Consistency**: Maintains professional LinkedIn tone

## 🛠️ Technologies Used

- **Frontend**: Streamlit with custom CSS styling
- **AI Models**: Groq (Llama 3), OpenAI GPT-3.5-turbo  
- **Web Scraping**: Selenium + Chrome WebDriver
- **Data Processing**: Pandas, LangChain
- **Deployment**: Python 3.8+

## 📦 Installation

### Prerequisites
- Python 3.8 or higher
- Chrome browser (for web scraping)
- API keys (Groq required, OpenAI optional)

### Quick Setup
```bash
# Clone and navigate to the project
cd Trending-Post-Generator

# Run the setup script
./run_app.sh

# Or manual setup:
python3 -m venv .venv
source .venv/bin/activate  # On Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
```

### 🔑 API Configuration
Create a `.env` file with your API keys:
```env
# Required - Free Groq API
GROQ_API_KEY=your_groq_api_key_here

# Optional - Premium OpenAI API  
OPENAI_API_KEY=your_openai_api_key_here

# Optional - LinkedIn credentials (for future features)
LINKEDIN_EMAIL=your_email@example.com
LINKEDIN_PASSWORD=your_password
```

**Get your Groq API key**: [https://console.groq.com/](https://console.groq.com/)

## 🚀 Usage

### Start the Application
```bash
source .venv/bin/activate
streamlit run app.py
```

### 🔥 Trending Topics Mode
1. Select "🔥 Trending Topics" in the sidebar
2. Choose AI provider (Groq free vs OpenAI premium)
3. Optional: Use sample trend for testing
4. Click "Generate Trending Post"
5. View and download your generated post

### ✨ Style-Based Mode
1. Select "✨ Style-Based Generation" in the sidebar  
2. Choose topic, length, and language
3. Or enter a custom topic
4. Click "Generate Style-Based Post"
5. View and download your customized post

## 📁 Project Structure

```
Trending-Post-Generator/
├── app.py                      # Main Streamlit application
├── ai_helper.py                # AI generation (Groq/OpenAI)
├── selenium_helper.py          # Google Trends scraping
├── few_shot_helper.py          # Few-shot learning logic
├── post_generator_unified.py   # Style-based post generation
├── llm_helper_unified.py       # LangChain LLM utilities
├── trend_fallback.py          # Sample trends for testing
├── requirements.txt           # Python dependencies
├── run_app.sh                # Setup and run script
├── .env                      # API keys and configuration
├── data/                     # Training data for few-shot learning
│   ├── processed_posts.json # Processed LinkedIn posts
│   └── raw_posts.json       # Raw post data
├── linkedin-posts/          # Generated posts storage
└── models/                  # Data models
```

## 🔧 Configuration Options

### Trending Mode
- **AI Provider**: Switch between Groq (free) and OpenAI (premium)
- **Live vs Sample**: Use real Google Trends or sample data
- **Auto-save**: Posts automatically saved with timestamps

### Style-Based Mode
- **Length**: Short (1-5 lines), Medium (6-10 lines), Long (11-15 lines)
- **Language**: English or Hinglish (Hindi + English mix)
- **Topics**: Choose from pre-defined tags or enter custom topics
- **Few-shot Examples**: Automatically uses relevant examples for style matching

## 📊 Data Sources

### Trending Topics
- **Google Trends**: Live trending searches (US market)
- **Minimum Threshold**: 10,000+ searches for relevance
- **Fallback Data**: Sample trends for testing/demo

### Style Training Data
- **Source**: Curated LinkedIn posts with engagement metrics
- **Processing**: Automated tag extraction and categorization
- **Languages**: English and Hinglish posts
- **Topics**: Business, Technology, Career, Leadership, etc.

## 🎯 Best Practices

### For Trending Posts
- Check trends during peak hours (9 AM - 5 PM)
- Review generated content for accuracy
- Add personal insights to trending topics
- Include relevant hashtags

### For Style-Based Posts  
- Use custom topics for niche subjects
- Experiment with different lengths for various audiences
- Combine with trending topics for maximum impact
- Maintain consistent posting schedule

## 🐛 Troubleshooting

### Common Issues

**"No trends found"**
- Enable "Use Sample Trend" for testing
- Check internet connection
- Verify Chrome browser installation

**"API key not configured"**
- Check `.env` file exists and contains valid keys
- Restart the application after updating keys

**"Import errors"**
- Run `pip install -r requirements.txt`
- Activate virtual environment before running

**"ChromeDriver issues"**
- Update Chrome browser to latest version
- Restart application to download latest ChromeDriver

## 🔮 Future Enhancements

- [ ] Direct LinkedIn posting integration
- [ ] Multi-language support (Spanish, French, etc.)
- [ ] Post scheduling and calendar
- [ ] Analytics and engagement tracking
- [ ] Team collaboration features
- [ ] Custom AI model fine-tuning
- [ ] Browser extension
- [ ] Mobile app version

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- **Groq** for free AI API access
- **Google Trends** for trending data
- **Streamlit** for the amazing web framework
- **LangChain** for LLM orchestration
- **Selenium** for web automation

---

**Made with ❤️ for the LinkedIn community**

*Generate engaging content • Save time • Boost engagement*
