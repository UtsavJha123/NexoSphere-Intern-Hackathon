import streamlit as st
import os
from datetime import datetime
from typing import Optional

# Import trending functionality
from selenium_helper import get_top_google_trend_today
from ai_helper import create_new_prompt, chat_with_ai
from trend_fallback import get_sample_trend

# Import few-shot functionality
from few_shot_helper import FewShotPosts
from post_generator_unified import generate_style_post

# Page configuration
st.set_page_config(
    page_title="LinkedIn Post Generator Assistant", 
    page_icon="📝",
    layout="wide"
)

# CSS for better styling
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 2rem 0;
        background: linear-gradient(90deg, #0077B5, #00A0DC);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 2.5rem;
        font-weight: bold;
    }
    .feature-box {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 4px solid #0077B5;
        margin: 1rem 0;
    }
    .generated-post {
        background-color: #ffffff;
        padding: 1.5rem;
        border-radius: 10px;
        border: 2px solid #0077B5;
        margin: 1rem 0;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
</style>
""", unsafe_allow_html=True)

# Main header
st.markdown('<h1 class="main-header">🚀 LinkedIn Post Generator Assistant</h1>', unsafe_allow_html=True)
st.markdown("### Generate engaging LinkedIn posts using trending topics or custom styles!")

# Sidebar for generation type selection
st.sidebar.header("🎯 Generation Mode")
generation_mode = st.sidebar.radio(
    "Choose your generation approach:",
    ["🔥 Trending Topics", "✨ Style-Based Generation"],
    help="Trending: Uses Google Trends data | Style-Based: Uses few-shot prompting from existing posts"
)

if generation_mode == "🔥 Trending Topics":
    # Trending Topics Mode
    st.markdown('<div class="feature-box">', unsafe_allow_html=True)
    st.header("🔥 Trending Topics Post Generator")
    st.markdown("**Generate posts based on today's hottest Google Trends!**")
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Configuration options
    col1, col2 = st.columns(2)
    
    with col1:
        use_openai = st.checkbox(
            "🚀 Use OpenAI (Premium)", 
            value=False,
            help="Uses GPT-3.5-turbo instead of Groq (requires OpenAI API key)"
        )
    
    with col2:
        use_fallback = st.checkbox(
            "🎲 Use Sample Trend", 
            value=False,
            help="Use a sample trend instead of scraping live Google Trends"
        )
    
    # Generate button
    if st.button("🔥 Generate Trending Post", type="primary", use_container_width=True):
        with st.spinner("🔍 Fetching trending topics and generating post..."):
            try:
                # Get trending topic
                if use_fallback:
                    st.info("🎲 Using sample trend data...")
                    top_trend = get_sample_trend()
                else:
                    st.info("🔍 Fetching live Google Trends...")
                    top_trend = get_top_google_trend_today()
                    if not top_trend:
                        st.warning("❌ No real trends found, using fallback...")
                        top_trend = get_sample_trend()

                if top_trend:
                    st.success(f"📈 Found trending topic: **{top_trend['subject']}**")
                    
                    # Generate post
                    prompt_content = create_new_prompt(top_trend["content"])
                    linkedin_post = chat_with_ai(prompt_content, use_openai=use_openai)
                    
                    if linkedin_post:
                        # Save post
                        os.makedirs('./linkedin-posts', exist_ok=True)
                        date = datetime.now().date()
                        safe_subject = "".join(c for c in top_trend['subject'] if c.isalnum() or c in (' ', '-', '_')).rstrip()
                        filename = f"./linkedin-posts/{safe_subject.replace(' ', '_')[:50]}_{date}.txt"
                        
                        with open(filename, "w", encoding="utf-8") as file:
                            file.write(linkedin_post)
                        
                        # Display result
                        st.markdown('<div class="generated-post">', unsafe_allow_html=True)
                        st.markdown("### 🎯 Generated LinkedIn Post:")
                        st.markdown(linkedin_post)
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        st.success(f"✅ Post saved to: {filename}")
                        st.info(f"💡 Generated using {'OpenAI (Premium)' if use_openai else 'Groq (Free)'} API")
                        
                        # Download button
                        st.download_button(
                            label="📥 Download Post",
                            data=linkedin_post,
                            file_name=f"linkedin_post_{date}.txt",
                            mime="text/plain"
                        )
                    else:
                        st.error("❌ Failed to generate post content")
                else:
                    st.error("❌ Could not fetch trending topics")
                    
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")

else:
    # Style-Based Generation Mode
    st.markdown('<div class="feature-box">', unsafe_allow_html=True)
    st.header("✨ Style-Based Post Generator")
    st.markdown("**Generate posts with specific style, length, and language using few-shot learning!**")
    st.markdown("</div>", unsafe_allow_html=True)
    
    # Load posts data
    @st.cache_data
    def load_posts():
        """Load posts data with caching for better performance"""
        return FewShotPosts()
    
    try:
        fs = load_posts()
        tags = fs.get_tags()
        
        # Configuration options
        col1, col2, col3 = st.columns(3)
        
        with col1:
            selected_tag = st.selectbox(
                "🏷️ Topic", 
                options=tags,
                help="Choose the topic/theme for your post"
            )
        
        with col2:
            selected_length = st.selectbox(
                "📏 Length", 
                options=["Short", "Medium", "Long"],
                help="Short: 1-5 lines | Medium: 6-10 lines | Long: 11-15 lines"
            )
        
        with col3:
            selected_language = st.selectbox(
                "🌐 Language", 
                options=["English", "Hinglish"],
                help="English or Hinglish (Hindi + English mix)"
            )
        
        # Custom topic input
        st.markdown("#### 💡 Or enter a custom topic:")
        custom_topic = st.text_input(
            "Custom Topic",
            placeholder="e.g., 'Remote Work Productivity', 'AI in Healthcare', etc.",
            help="Enter any topic you want to write about"
        )
        
        # Generate button
        if st.button("✨ Generate Style-Based Post", type="primary", use_container_width=True):
            topic_to_use = custom_topic.strip() if custom_topic.strip() else selected_tag
            
            with st.spinner(f"✨ Generating {selected_length.lower()} {selected_language} post about '{topic_to_use}'..."):
                try:
                    post = generate_style_post(selected_length, selected_language, topic_to_use)
                    
                    if post:
                        # Display result
                        st.markdown('<div class="generated-post">', unsafe_allow_html=True)
                        st.markdown("### 🎯 Generated LinkedIn Post:")
                        st.markdown(post)
                        st.markdown("</div>", unsafe_allow_html=True)
                        
                        st.success("✅ Post generated successfully!")
                        
                        # Save and download options
                        date = datetime.now().date()
                        filename = f"style_post_{topic_to_use.replace(' ', '_')[:30]}_{date}.txt"
                        
                        st.download_button(
                            label="📥 Download Post",
                            data=post,
                            file_name=filename,
                            mime="text/plain"
                        )
                    else:
                        st.error("❌ Failed to generate post content")
                        
                except Exception as e:
                    st.error(f"❌ Error generating post: {str(e)}")
                    st.error("Please check your API configuration and try again.")
    
    except Exception as e:
        st.error(f"❌ Error loading post data: {str(e)}")
        st.info("💡 Make sure the processed_posts.json file exists in the data/ directory")

# Footer
st.markdown("---")
st.markdown(
    "Made with ❤️ using Streamlit | "
    "🔥 Trending mode uses Google Trends + Groq/OpenAI | "
    "✨ Style mode uses Few-Shot Learning"
)
