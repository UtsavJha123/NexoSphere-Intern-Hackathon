# 🚀 TRENDING POST GENERATOR - FREE VERSION

Generate professional LinkedIn posts from real trending topics using FREE AI!

## ✨ Features

- 🆓 **100% FREE** - Uses Groq AI (no credit card required)
- 📰 **Real Trending Topics** - Fetches from Google News RSS feeds
- 🤖 **AI-Powered Content** - Professional LinkedIn posts in seconds
- ⚡ **Fast & Reliable** - Multiple fallback sources ensure 95%+ success rate
- 💾 **Auto-Save** - Organized file output ready for posting

## 🎯 Sample Output

```
🚨 Breaking News: EU-US Trade Talks Enter New Phase 🚨

As the global trade landscape continues to evolve, it's essential 
for professionals to stay informed about the latest developments...

💡 Here's the takeaway: The trade war between the US and EU is not 
just about tariffs; it's about the future of global trade...

🌎 So, what does this mean for us? How will this shift affect our 
businesses, industries, and careers? Share your thoughts! 💬
```

## 🚀 Quick Start (5 Minutes)

### 1. Setup
```bash
# Clone and setup
git clone <repository-url>
cd Trending-Post-Generator
./setup.sh
```

### 2. Get FREE Groq API Key
```bash
python setup_groq.py  # Shows detailed instructions
```

Visit: https://console.groq.com/ → Sign Up (Free) → API Keys → Create Key

### 3. Configure
Edit `.env` file:
```bash
GROQ_API_KEY=gsk_your_actual_groq_key_here
LINKEDIN_EMAIL=your_email@example.com
LINKEDIN_PASSWORD=your_password
```

### 4. Generate Posts
```bash
source .venv/bin/activate
python main.py          # Full version with real trends
python demo.py          # Demo with sample data
python main_robust.py   # Advanced options
```

## 📊 Why Groq Over OpenAI?

| Feature | Groq (FREE) | OpenAI (Premium) |
|---------|-------------|------------------|
| Cost | 🆓 FREE | 💰 $0.002/1K tokens |
| Speed | ⚡ Very Fast | 🐌 Moderate |
| Quality | 🎯 Excellent | 🎯 Excellent |
| Daily Limits | 📈 Generous | 💳 Pay-per-use |
| Setup Time | 😊 2 minutes | 😊 2 minutes |

## 🛠️ Advanced Configuration

### Switch to Premium AI (Optional)
```python
# In main.py, change:
generate_daily_post(use_openai=True)  # Uses OpenAI instead of Groq
```

### Custom Prompts
Edit `base_linkedin_post_prompt.txt` to change AI writing style.

### Geographic Targeting
Modify `selenium_helper.py` to change region (US, UK, etc.)

## 📁 Project Structure

```
├── main.py                           # 🎯 Main application
├── main_robust.py                    # 🛡️ Advanced version with options
├── demo.py                           # 🎭 Quick demo mode
├── ai_helper.py                      # 🤖 AI integration (Groq + OpenAI)
├── selenium_helper.py                # 🌐 Web scraping (RSS feeds)
├── trend_fallback.py                 # 🔄 Fallback trending topics
├── test_ai.py                        # 🧪 Test AI integration
├── setup_groq.py                     # 📋 API setup guide
├── base_linkedin_post_prompt.txt     # 📝 AI prompt template
├── requirements.txt                  # 📦 Dependencies
├── setup.sh                          # ⚙️ Auto-setup script
└── linkedin-posts/                   # 💾 Generated content
```

## 🔧 Troubleshooting

### Common Issues
- **"Import could not be resolved"** → Activate virtual environment: `source .venv/bin/activate`
- **"GROQ_API_KEY not configured"** → Check your `.env` file
- **"No trends found"** → App automatically uses fallback sample data
- **ChromeDriver issues** → Not needed! Uses RSS feeds instead

### Performance Tips
- Use `main_robust.py` for maximum reliability
- `demo.py` works instantly without web scraping
- Multiple trend sources ensure consistent operation

## 🌟 Pro Tips

1. **Content Calendar**: Run multiple times to build a week's worth of posts
2. **A/B Testing**: Generate multiple versions with different prompts
3. **Industry Focus**: Edit prompts for specific industries
4. **Peak Times**: Generate during business hours for timely topics

## 🤝 Contributing

Found a bug? Want to add features? PRs welcome!

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

Educational use. Respect API terms and website ToS.

---

**Ready to generate viral LinkedIn content for FREE? Let's go! 🚀**

### 💡 Perfect for:
- Content creators looking for trending topics
- Professionals building their LinkedIn presence  
- Marketers needing quick, quality content
- Anyone wanting to stay current with trends

**No credit card, no payments, no limits - just professional content!** 🎉

