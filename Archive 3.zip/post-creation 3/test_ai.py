#!/usr/bin/env python3
"""
Test script to verify AI integration is working
"""

from ai_helper import chat_with_ai
import os
from dotenv import load_dotenv

load_dotenv()

def test_ai_integration():
    print("🧪 Testing AI Integration...")
    print("="*40)
    
    # Check API keys
    groq_key = os.environ.get("GROQ_API_KEY")
    openai_key = os.environ.get("OPENAI_API_KEY")
    
    print(f"🔑 Groq API Key: {'✅ Configured' if groq_key and groq_key != 'your_groq_api_key_here' else '❌ Not configured'}")
    print(f"🔑 OpenAI API Key: {'✅ Configured' if openai_key and openai_key != 'your_openai_api_key_here' else '❌ Not configured'}")
    print()
    
    # Test prompt
    test_prompt = """
    Create a short LinkedIn post about this trending topic:
    
    "Artificial Intelligence is being integrated into everyday workplace tools, 
    with 73% of companies planning to adopt AI solutions in the next year."
    
    Make it engaging and professional.
    """
    
    print("🤖 Testing Groq API (Free)...")
    result = chat_with_ai(test_prompt, use_openai=False)
    
    if result:
        print("✅ Groq API test successful!")
        print("📝 Sample output:")
        print("-" * 30)
        print(result[:200] + "..." if len(result) > 200 else result)
        print("-" * 30)
    else:
        print("❌ Groq API test failed")
        
        if openai_key and openai_key != 'your_openai_api_key_here':
            print("🔄 Testing OpenAI fallback...")
            result = chat_with_ai(test_prompt, use_openai=True)
            if result:
                print("✅ OpenAI fallback successful!")
            else:
                print("❌ OpenAI fallback also failed")
    
    print("\n" + "="*40)
    if result:
        print("🎉 AI integration is working! Ready to generate posts.")
    else:
        print("❌ AI integration failed. Please check your API keys.")
        print("\n💡 To fix:")
        print("1. Run: python setup_groq.py")
        print("2. Get your free Groq API key")
        print("3. Update your .env file")

if __name__ == "__main__":
    test_ai_integration()
