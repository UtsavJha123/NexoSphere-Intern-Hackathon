"""
Free LLM Client - Handles free LLM API calls as alternatives to OpenAI
Supports Hugging Face Inference API and Groq (both have free tiers)
"""

import os
import requests
import json
from typing import Dict, Any, Optional
import time


class FreeLLMClient:
    def __init__(self):
        self.hf_api_key = os.getenv('HUGGINGFACE_API_KEY')
        self.groq_api_key = os.getenv('GROQ_API_KEY')
        self.perplexity_api_key = os.getenv('OPENAI_API_KEY')  # Using the existing key which is actually Perplexity
        self.provider = os.getenv('FREE_LLM_PROVIDER', 'perplexity')
        
        # Hugging Face model endpoints (free inference API)
        self.hf_models = {
            'meta-llama/Llama-2-7b-chat-hf': 'https://api-inference.huggingface.co/models/meta-llama/Llama-2-7b-chat-hf',
            'microsoft/DialoGPT-medium': 'https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium',
            'facebook/blenderbot-400M-distill': 'https://api-inference.huggingface.co/models/facebook/blenderbot-400M-distill',
            'HuggingFaceH4/zephyr-7b-beta': 'https://api-inference.huggingface.co/models/HuggingFaceH4/zephyr-7b-beta'
        }
        
        print(f"🤖 Free LLM Client initialized with provider: {self.provider}")
    
    def generate_content(self, system_prompt: str, user_prompt: str, max_tokens: int = 300) -> str:
        """Generate content using free LLM providers"""
        
        if self.provider == 'perplexity' and self.perplexity_api_key:
            return self._generate_with_perplexity(system_prompt, user_prompt, max_tokens)
        elif self.provider == 'groq' and self.groq_api_key:
            return self._generate_with_groq(system_prompt, user_prompt, max_tokens)
        elif self.provider == 'huggingface':
            return self._generate_with_huggingface(system_prompt, user_prompt, max_tokens)
        else:
            return self._generate_fallback(user_prompt)
    
    def _generate_with_perplexity(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        """Generate content using Perplexity API"""
        try:
            headers = {
                "Authorization": f"Bearer {self.perplexity_api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": "llama-3.1-sonar-small-128k-online",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                "max_tokens": max_tokens,
                "temperature": 0.7,
                "top_p": 0.9,
                "return_citations": False,
                "search_domain_filter": ["perplexity.ai"],
                "return_images": False,
                "return_related_questions": False,
                "search_recency_filter": "month",
                "top_k": 0,
                "stream": False,
                "presence_penalty": 0,
                "frequency_penalty": 1
            }
            
            response = requests.post(
                "https://api.perplexity.ai/chat/completions",
                headers=headers,
                json=payload,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"].strip()
            else:
                print(f"⚠️ Perplexity API failed with status {response.status_code}: {response.text}")
                return self._generate_with_huggingface(system_prompt, user_prompt, max_tokens)
                
        except Exception as e:
            print(f"⚠️ Perplexity API failed: {str(e)}")
            return self._generate_with_huggingface(system_prompt, user_prompt, max_tokens)
    
    def _generate_with_groq(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        """Generate content using Groq API (free tier available)"""
        try:
            from groq import Groq
            client = Groq(api_key=self.groq_api_key)
            
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                model="llama3-8b-8192",  # Free model
                max_tokens=max_tokens,
                temperature=0.7
            )
            
            return chat_completion.choices[0].message.content
            
        except Exception as e:
            print(f"⚠️ Groq API failed: {str(e)}")
            return self._generate_with_huggingface(system_prompt, user_prompt, max_tokens)
    
    def _generate_with_huggingface(self, system_prompt: str, user_prompt: str, max_tokens: int) -> str:
        """Generate content using Hugging Face Inference API (free tier)"""
        
        # If no HF API key, use free public models or fallback
        if not self.hf_api_key:
            print("ℹ️ No HuggingFace API key - using template-based generation")
            return self._generate_smart_fallback(system_prompt, user_prompt)
        
        # Combine prompts for better context
        combined_prompt = f"{system_prompt}\n\nUser: {user_prompt}\nAssistant:"
        
        # Try different models in order of preference
        models_to_try = [
            'HuggingFaceH4/zephyr-7b-beta',
            'meta-llama/Llama-2-7b-chat-hf', 
            'microsoft/DialoGPT-medium',
            'facebook/blenderbot-400M-distill'
        ]
        
        for model_name in models_to_try:
            try:
                response = self._call_hf_api(model_name, combined_prompt, max_tokens)
                if response and len(response.strip()) > 10:
                    return response
            except Exception as e:
                print(f"⚠️ Model {model_name} failed: {str(e)}")
                continue
        
        # If all models fail, return smart fallback
        return self._generate_smart_fallback(system_prompt, user_prompt)
    
    def _generate_smart_fallback(self, system_prompt: str, user_prompt: str) -> str:
        """Smart template-based content generation without external APIs"""
        
        # Check if this is a job analysis request (different from content creation)
        if 'job title:' in user_prompt.lower() and 'profile:' in user_prompt.lower():
            return self._analyze_job_match_fallback(user_prompt)
        
        # Analyze the user prompt for context (for content creation)
        prompt_lower = user_prompt.lower()
        
        # Job-related content
        if any(word in prompt_lower for word in ['job', 'career', 'opportunity', 'hiring', 'position']):
            if 'san francisco' in prompt_lower or 'sf' in prompt_lower:
                return """🌉 Exploring exciting opportunities in San Francisco!

The Bay Area continues to be a hub of innovation and cutting-edge technology. I'm actively connecting with forward-thinking companies that are shaping the future.

San Francisco's tech ecosystem offers incredible potential for growth and learning. From startups to established firms, the diversity of opportunities is inspiring.

Open to discussions about roles in software engineering, AI, and emerging technologies. Let's connect!

#SanFrancisco #TechCareers #Innovation #BayArea #SoftwareEngineering"""
            
            elif any(city in prompt_lower for city in ['bangalore', 'mumbai', 'delhi', 'hyderabad', 'india']):
                return """🇮🇳 Excited about the thriving tech landscape in India!

India's technology sector continues to lead global innovation with its talented workforce and dynamic startup ecosystem.

Looking forward to contributing to this growth story and connecting with teams that are building the next generation of solutions.

Always interested in discussing opportunities in software development, AI, and digital transformation.

#IndianTech #Innovation #SoftwareDevelopment #TechCareers #DigitalIndia"""
            
            else:
                return """🚀 Actively exploring new career opportunities!

Passionate about leveraging technology to solve complex problems and drive innovation. My experience spans multiple domains and I'm excited about the next chapter.

Looking to connect with organizations that value creativity, collaboration, and continuous learning.

What exciting projects are you working on? Let's discuss how we can create value together!

#CareerGrowth #TechOpportunities #Innovation #Networking #SoftwareEngineering"""
        
        # AI/ML related content
        elif any(word in prompt_lower for word in ['ai', 'artificial intelligence', 'machine learning', 'ml', 'deep learning', 'neural']):
            return """🤖 The future of AI is incredibly exciting!

Artificial Intelligence continues to revolutionize how we solve problems and create value across industries. From natural language processing to computer vision, the possibilities are endless.

Recently been diving deeper into the latest developments in machine learning and their real-world applications. The pace of innovation is remarkable!

What AI trends are capturing your attention? Would love to exchange insights and learn from the community!

#ArtificialIntelligence #MachineLearning #DeepLearning #Innovation #TechTrends"""
        
        # Project/achievement related content
        elif any(word in prompt_lower for word in ['project', 'built', 'created', 'developed', 'launched']):
            project_type = "innovative project"
            if 'ai' in prompt_lower or 'ml' in prompt_lower:
                project_type = "AI project"
            elif 'web' in prompt_lower or 'app' in prompt_lower:
                project_type = "application"
            elif 'data' in prompt_lower:
                project_type = "data project"
                
            return f"""✨ Thrilled to share my latest {project_type}!

Building this solution has been an incredible journey of learning and innovation. It's amazing how technology can be leveraged to create meaningful impact.

The process involved overcoming interesting technical challenges and implementing creative solutions. Each step taught me something valuable.

Excited to see how this contributes to the broader tech community and opens doors for future collaborations!

#ProjectLaunch #Innovation #TechBuild #SoftwareDevelopment #Learning"""
        
        # Technology/learning content
        elif any(word in prompt_lower for word in ['technology', 'tech', 'programming', 'coding', 'development']):
            return """💻 The ever-evolving world of technology never ceases to amaze!

Staying current with the latest developments in software engineering and emerging technologies is both challenging and rewarding. Every day brings new opportunities to learn and grow.

From cloud computing to AI, from mobile development to DevOps - the landscape is rich with possibilities for innovation.

What technologies are you most excited about? Let's share our experiences and learn together!

#Technology #Programming #SoftwareDevelopment #Innovation #ContinuousLearning"""
        
        # General professional content
        else:
            return """🌟 Reflecting on growth and opportunities ahead!

The tech industry offers endless possibilities for learning, innovation, and making a meaningful impact. Every interaction and project teaches valuable lessons.

Grateful for the journey so far and excited about what lies ahead. Building connections and sharing knowledge makes the path even more rewarding.

Looking forward to collaborating with fellow professionals and contributing to exciting projects!

#ProfessionalGrowth #Networking #Innovation #Technology #Collaboration"""

    def _analyze_job_match_fallback(self, analysis_prompt: str) -> str:
        """Analyze job match based on the provided job and profile information"""
        import re
        
        # Extract key information from the prompt
        skills_match = re.search(r'skills:\s*([^\\n]+)', analysis_prompt.lower())
        job_title_match = re.search(r'job title:\s*([^\\n]+)', analysis_prompt.lower())
        experience_match = re.search(r'experience:\s*([^\\n]+)', analysis_prompt.lower())
        location_match = re.search(r'location:\s*([^\\n]+)', analysis_prompt.lower())
        
        user_skills = skills_match.group(1).split(',') if skills_match else []
        job_title = job_title_match.group(1) if job_title_match else ""
        user_experience = experience_match.group(1) if experience_match else ""
        job_location = location_match.group(1) if location_match else ""
        
        # Simple skill matching
        relevant_skills = []
        job_text_lower = analysis_prompt.lower()
        
        for skill in user_skills:
            skill_clean = skill.strip()
            if skill_clean and (skill_clean in job_text_lower or skill_clean in job_title.lower()):
                relevant_skills.append(skill_clean)
        
        # Analyze location match
        location_comment = ""
        if 'india' in job_location.lower() and 'san francisco' in analysis_prompt.lower():
            location_comment = "Location might require consideration. "
        elif 'remote' in job_location.lower():
            location_comment = "Remote position offers flexibility. "
        
        # Generate match analysis
        if len(relevant_skills) >= 3:
            match_strength = "Strong"
        elif len(relevant_skills) >= 2:
            match_strength = "Good"
        elif len(relevant_skills) >= 1:
            match_strength = "Moderate"
        else:
            match_strength = "Weak"
            
        skills_text = f"Found {len(relevant_skills)} relevant skill(s) in job requirements. " if relevant_skills else "Limited skill overlap identified. "
        
        return f"{match_strength} match. {skills_text}{location_comment}"
    
    def _call_hf_api(self, model_name: str, prompt: str, max_tokens: int) -> str:
        """Call Hugging Face Inference API"""
        
        api_url = self.hf_models.get(model_name)
        if not api_url:
            raise Exception(f"Model {model_name} not found")
        
        headers = {}
        if self.hf_api_key:
            headers["Authorization"] = f"Bearer {self.hf_api_key}"
        
        payload = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": max_tokens,
                "temperature": 0.7,
                "do_sample": True,
                "return_full_text": False
            }
        }
        
        # Make API call
        response = requests.post(api_url, headers=headers, json=payload, timeout=30)
        
        if response.status_code == 503:
            # Model is loading, wait and retry
            print(f"🔄 Model {model_name} is loading, waiting...")
            time.sleep(10)
            response = requests.post(api_url, headers=headers, json=payload, timeout=60)
        
        response.raise_for_status()
        result = response.json()
        
        if isinstance(result, list) and len(result) > 0:
            generated_text = result[0].get('generated_text', '')
            return generated_text.strip()
        elif isinstance(result, dict):
            return result.get('generated_text', '').strip()
        else:
            raise Exception(f"Unexpected response format: {result}")
    
    def _generate_fallback(self, user_prompt: str) -> str:
        """Fallback content generation when all APIs fail"""
        
        # Simple template-based generation
        if 'job' in user_prompt.lower() or 'career' in user_prompt.lower():
            return """🚀 Excited to share my career journey!

I'm actively exploring new opportunities in tech and looking forward to connecting with innovative teams. 

My experience includes working with modern technologies and I'm passionate about building solutions that make a difference.

Always open to discussing new projects and collaborations! 

#CareerGrowth #Tech #Opportunities #Innovation"""
        
        elif 'ai' in user_prompt.lower() or 'machine learning' in user_prompt.lower():
            return """🤖 Diving deep into AI and Machine Learning!

The field of artificial intelligence continues to amaze me with its potential to transform industries and solve complex problems.

Recently been exploring the latest developments in LLMs, computer vision, and data science.

What AI trends are you most excited about? Let's connect and share insights!

#AI #MachineLearning #DataScience #Innovation #Tech"""
        
        else:
            return f"""💡 Sharing some thoughts on {user_prompt}!

It's fascinating how technology continues to evolve and create new opportunities for growth and innovation.

Always learning something new and excited to apply these insights in real-world projects.

What's your take on this? Would love to hear your perspective!

#Learning #Growth #Innovation #Technology #Networking"""


# Test function
def test_free_llm():
    """Test the free LLM client"""
    client = FreeLLMClient()
    
    system_prompt = "You are a LinkedIn content expert. Create engaging, professional posts."
    user_prompt = "Create a post about my AI project"
    
    result = client.generate_content(system_prompt, user_prompt)
    print("Generated content:")
    print(result)


if __name__ == "__main__":
    test_free_llm()
