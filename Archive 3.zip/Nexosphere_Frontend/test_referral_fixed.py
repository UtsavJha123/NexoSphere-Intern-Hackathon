#!/usr/bin/env python3

import sys
import os

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import required modules
import re
import requests
from datetime import datetime
from free_llm_client import FreeLLMClient

def extract_companies_from_message(message):
    # Make extraction case-insensitive and trim whitespace
    pattern = r"(?:at|in|for)\s+([a-zA-Z0-9& ]+)"
    matches = re.findall(pattern, message, re.IGNORECASE)
    return [m.strip().title() for m in matches]

def calculate_experience_years(experience_list):
    total_years = 0
    now = datetime.now()
    for exp in experience_list:
        start_date = exp.get('start_date')
        end_date = exp.get('end_date')
        if start_date:
            if isinstance(start_date, str):
                try:
                    start_date = datetime.fromisoformat(start_date)
                except Exception:
                    continue
        else:
            continue
        if end_date:
            if isinstance(end_date, str):
                try:
                    end_date = datetime.fromisoformat(end_date)
                except Exception:
                    end_date = now
        else:
            end_date = now
        diff = (end_date - start_date).days / 365.25
        if diff > 0:
            total_years += diff
    return round(total_years, 1)

def handle_referal_request(usermessage):
    # Step 1: Extract companies from the user message
    companies = extract_companies_from_message(usermessage)
    if not companies:
        return {'message': 'Could not identify any companies in your request. Please specify the companies you want referrals for.'}

    # Step 2: Fetch all user profiles from backend API
    api_url = "http://127.0.0.1:8080/api/users"
    try:
        response = requests.get(api_url)
        if response.status_code != 200:
            return {'message': 'Failed to retrieve user profiles from backend.'}
        profiles = response.json()
    except Exception as e:
        return {'message': f'Error connecting to backend API: {str(e)}'}

    # Debug: Show what companies we're looking for
    print(f"🔍 Looking for referrals to companies: {companies}")

    # Step 3: Filter profiles currently working at the requested companies
    filtered_profiles = []
    for profile in profiles:
        experience = profile.get('experience', [])
        for exp in experience:
            current_company = exp.get('current_company')
            title = exp.get('title', '')
            
            # Skip if current_company is None or empty
            if not current_company:
                continue
                
            # Check if any requested company name matches the current company
            if any(company.lower() in current_company.lower() for company in companies):
                exp_years = calculate_experience_years([exp])
                filtered_profiles.append({
                    'profile': profile,
                    'experience_years': exp_years,
                    'title': title,
                    'current_company': current_company
                })
                print(f"✅ Found match: {profile.get('name')} works at {current_company}")
                break

    print(f"📊 Found {len(filtered_profiles)} matching profiles")

    if not filtered_profiles:
        # Show available companies for debugging
        available_companies = set()
        for profile in profiles:
            for exp in profile.get('experience', []):
                company = exp.get('current_company')
                if company:
                    available_companies.add(company)
        
        available_list = list(available_companies)[:10]  # Show first 10
        return {
            'message': f'No user profiles found working at: {", ".join(companies)}.\n\nAvailable companies include: {", ".join(available_list)}{"..." if len(available_companies) > 10 else ""}'
        }

    # Step 4: Use LLM to rank top 3 profiles by experience, then title
    try:
        llm_client = FreeLLMClient()
        prompt_profiles = []
        for idx, item in enumerate(filtered_profiles, 1):
            p = item['profile']
            name = p.get('name', 'Unknown')
            title = item['title']
            exp_years = item['experience_years']
            prompt_profiles.append(
                f"Profile_{idx}: Name: {name}, Title: {title}, Company: {item['current_company']}, Experience: {exp_years} years"
            )

        system_prompt = (
            "You are an expert career advisor. Given a list of user profiles with their name, title, company, and years of experience, "
            "and a user request for referrals to specific companies, select the top 3 best candidates for referral. "
            "First, prioritize by highest years of experience at the company, then by most relevant title. "
            "Respond with the top 3 profile names and a brief explanation for your ranking."
        )

        user_prompt = (
                f"User request: {usermessage}\n"
                f"Companies: {', '.join(companies)}\n"
                f"Candidate profiles:\n" + "\n".join(prompt_profiles)
        )

        print(f"🤖 Calling LLM with {len(prompt_profiles)} profiles...")
        llm_response = llm_client.generate_content(system_prompt, user_prompt, max_tokens=500)
        print(f"✅ LLM Response received: {llm_response[:100]}...")

        # Attempt to extract top 3 names from the LLM response
        top_3_names = []
        lines = llm_response.split('\n')
        for line in lines:
            for item in filtered_profiles:
                if item['profile'].get('name', '') in line:
                    top_3_names.append(item['profile'].get('name', 'Unknown'))
                    if len(top_3_names) >= 3:
                        break
            if len(top_3_names) >= 3:
                break

        top_3_profiles = [item['profile'] for item in filtered_profiles if item['profile'].get('name', '') in top_3_names]

        return {
            'message': f'Top 3 referral candidates for companies {", ".join(companies)}:\n\n{llm_response}',
            'data': {
                'top_candidates': top_3_profiles,
                'llm_reasoning': llm_response
            }
        }
    except Exception as e:
        print(f"❌ LLM Error: {str(e)}")
        # Fallback: return all matching profiles if LLM fails
        return {
            'message': f'Found {len(filtered_profiles)} referral candidates for {", ".join(companies)} (LLM ranking unavailable: {str(e)}):',
            'data': {
                'top_candidates': [item['profile'] for item in filtered_profiles[:3]],
                'llm_reasoning': f'LLM error: {str(e)}'
            }
        }

if __name__ == "__main__":
    print("Testing handle_referal_request function with LLM...")
    print("=" * 60)
    
    # Test with Barnes LLC (should have LLM ranking)
    print("Test 1 - Barnes LLC (should have LLM ranking):")
    result = handle_referal_request('I want referral for Barnes LLC')
    print(f"Message: {result['message']}")
    if 'data' in result:
        print(f"Top candidates: {len(result['data'].get('top_candidates', []))}")
        print(f"LLM reasoning: {result['data'].get('llm_reasoning', 'None')[:100]}...")
    print()
    
    # Test with Hogan Group (should have LLM ranking)
    print("Test 2 - Hogan Group (should have LLM ranking):")
    result = handle_referal_request('I want referral for Hogan Group')
    print(f"Message: {result['message']}")
    if 'data' in result:
        print(f"Top candidates: {len(result['data'].get('top_candidates', []))}")
        print(f"LLM reasoning: {result['data'].get('llm_reasoning', 'None')[:100]}...")
    print()
