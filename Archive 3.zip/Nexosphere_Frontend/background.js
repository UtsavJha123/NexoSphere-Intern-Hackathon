// Background service worker for Chrome extension
class LinkedInAssistantBackground {
    constructor() {
        this.linkedinAPI = null;
        this.serverURL = 'http://localhost:5003';
        this.init();
    }

    init() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true; // Keep message channel open for async response
        });

        chrome.runtime.onInstalled.addListener(() => {
            console.log('LinkedIn AI Assistant installed');
        });
    }

    async handleMessage(message, sender, sendResponse) {
        try {
            switch (message.action) {
                case 'connectLinkedIn':
                    const connectResult = await this.connectToLinkedIn(message.credentials);
                    sendResponse(connectResult);
                    break;

                case 'getUserProfile':
                    const profileResult = await this.getUserProfile();
                    sendResponse(profileResult);
                    break;

                case 'searchJobs':
                    const jobsResult = await this.searchJobs(message.query);
                    sendResponse(jobsResult);
                    break;

                case 'createLinkedInPost':
                    const basicPostResult = await this.createPost(message.content);
                    sendResponse(basicPostResult);
                    break;

                case 'analyzeTrendingPosts':
                    const trendsResult = await this.analyzeTrendingPosts(
                        message.topic,
                        message.scrapedPosts || null
                    );
                    sendResponse(trendsResult);
                    break;

                case 'optimizePost':
                    const optimizeResult = await this.optimizePost(
                        message.content, 
                        message.trends || null
                    );
                    sendResponse(optimizeResult);
                    break;
                    
                case 'createPost':
                    const postResult = await this.createPost(
                        message.content,
                        message.publish || false,
                        message.profileData || null
                    );
                    sendResponse(postResult);
                    break;

                case 'checkConnection':
                    sendResponse({ connected: this.linkedinAPI !== null });
                    break;

                case 'disconnect':
                    this.linkedinAPI = null;
                    sendResponse({ success: true });
                    break;

                default:
                    sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background script error:', error);
            sendResponse({ success: false, error: error.message });
        }
    }

    async connectToLinkedIn(credentials) {
        try {
            // Test connection by calling our backend server
            const response = await fetch(`${this.serverURL}/api/connect`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(credentials)
            });

            const result = await response.json();
            
            if (result.success) {
                this.linkedinAPI = { connected: true, credentials };
                return { success: true, profile: result.profile };
            } else {
                throw new Error(result.error || 'Connection failed');
            }
        } catch (error) {
            console.error('LinkedIn connection failed:', error);
            return { success: false, error: error.message };
        }
    }

    async getUserProfile() {
        if (!this.linkedinAPI) {
            return { success: false, error: 'Not connected to LinkedIn' };
        }

        try {
            const response = await fetch(`${this.serverURL}/api/profile`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            const result = await response.json();
            
            if (result.success) {
                return { success: true, profile: result.profile };
            } else {
                throw new Error(result.error || 'Failed to fetch profile');
            }
        } catch (error) {
            console.error('Failed to fetch profile:', error);
            return { success: false, error: error.message };
        }
    }

    async searchJobs(query) {
        try {
            const response = await fetch(`${this.serverURL}/api/jobs`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ query })
            });

            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Job search failed:', error);
            return { success: false, error: error.message };
        }
    }

    async createPost(content) {
        try {
            const response = await fetch(`${this.serverURL}/api/post`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ content })
            });

            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Post creation failed:', error);
            return { success: false, error: error.message };
        }
    }

    async analyzeTrendingPosts(topic, scrapedPosts = null) {
        try {
            let requestBody = { topic };
            
            // Include scraped post data from LinkedIn if available
            if (scrapedPosts && scrapedPosts.length > 0) {
                requestBody.scrapedPosts = scrapedPosts;
            }
            
            // Get real profile data if available
            const storage = await chrome.storage.local.get(['realProfileData']);
            if (storage.realProfileData) {
                requestBody.profileData = storage.realProfileData;
            }
            
            const response = await fetch(`${this.serverURL}/api/analyze-trends`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestBody)
            });

            const result = await response.json();
            
            // Cache trend results for future optimization
            if (result.success && result.trends) {
                await chrome.storage.local.set({ 'cachedTrends': result.trends });
            }
            
            return result;
        } catch (error) {
            console.error('Trend analysis failed:', error);
            return { success: false, error: error.message };
        }
    }

    async optimizePost(content, trends = null) {
        try {
            // Get cached trends if not provided
            if (!trends) {
                const storage = await chrome.storage.local.get(['cachedTrends']);
                trends = storage.cachedTrends || [];
            }
            
            // Get real profile data if available
            const storage = await chrome.storage.local.get(['realProfileData']);
            const profileData = storage.realProfileData || null;
            
            const response = await fetch(`${this.serverURL}/api/optimize-post`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    content,
                    trends,
                    profileData
                })
            });

            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Post optimization failed:', error);
            return { success: false, error: error.message };
        }
    }
    
    async createPost(content, publish = false, profileData = null) {
        try {
            // Get real profile data if not provided
            if (!profileData) {
                const storage = await chrome.storage.local.get(['realProfileData']);
                profileData = storage.realProfileData || null;
            }
            
            const response = await fetch(`${this.serverURL}/api/post`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    content,
                    publish,
                    profileData
                })
            });

            const result = await response.json();
            return result;
        } catch (error) {
            console.error('Post creation failed:', error);
            return { success: false, error: error.message };
        }
    }
}

// Initialize background script
new LinkedInAssistantBackground();
