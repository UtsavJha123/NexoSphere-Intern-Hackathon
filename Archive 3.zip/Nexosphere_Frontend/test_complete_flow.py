#!/usr/bin/env python3

import sys
import os

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import from the main app
from app import detect_intent, handle_discussion_forum

def test_complete_flow():
    """Test the complete flow from intent detection to forum handling"""
    
    # Test messages that should be detected as discussion_forum intent
    test_messages = [
        'What do you think about remote work?',
        'I want to discuss AI trends',
        'Can I get community feedback on this?',
        'Looking for opinions on career change'
    ]

    print('Testing intent detection and forum handling...')
    print('=' * 60)

    for message in test_messages:
        try:
            intent = detect_intent(message)
            print(f'Message: "{message}"')
            print(f'Detected intent: {intent}')
            
            if intent == 'discussion_forum':
                result = handle_discussion_forum(message)
                print(f'✅ Redirected to: {result["data"]["redirect_url"]}')
                print(f'Action: {result["data"]["action"]}')
            else:
                print(f'❌ Not detected as forum intent')
            print('-' * 40)
        except Exception as e:
            print(f'Error testing message "{message}": {e}')
            print('-' * 40)

if __name__ == "__main__":
    test_complete_flow()
