"""
LinkedIn Assistant Core Module
Implements the main functionality for LinkedIn content posting and job matching
"""

import os
import json
import time
from typing import Dict, List, Any, Optional
import requests
from linkedin_api import Linkedin
from openai import OpenAI
from free_llm_client import FreeLLMClient


class LinkedInAssistant:
    """Main class for LinkedIn Assistant functionality"""

    def __init__(self, email=None, password=None):
        """Initialize the LinkedIn Assistant with API credentials

        Args:
            email: Optional LinkedIn email to override environment variable
            password: Optional LinkedIn password to override environment variable
        """
        self.linkedin_api = None
        self.openai_client = None
        self.free_llm_client = None
        self.use_free_llm = os.getenv('USE_FREE_LLM', 'false').lower() == 'true'
        self.custom_credentials = None

        # Store custom credentials if provided
        if email and password:
            self.custom_credentials = {
                'email': email,
                'password': password
            }

        self._setup_apis()

    def _setup_apis(self):
        """Setup LinkedIn and AI API connections"""
        try:
            # Setup LinkedIn API using custom credentials or environment variables
            if self.custom_credentials:
                username = self.custom_credentials['email']
                password = self.custom_credentials['password']
                print(f"🔐 Connecting to LinkedIn as {username}...")
            else:
                username = os.getenv('LI_USER')
                password = os.getenv('LI_PASS')
                print("🔐 Connecting to LinkedIn using environment variables...")

            if username and password:
                try:
                    self.linkedin_api = Linkedin(username, password)
                    print("✅ LinkedIn connection established")
                except Exception as e:
                    print(f"⚠️ LinkedIn connection failed: {str(e)}")
            else:
                print("⚠️ LinkedIn credentials not found - content posting will be in dry-run mode")

            # Setup AI APIs
            if self.use_free_llm:
                print("🤖 Using Free LLM APIs...")
                self.free_llm_client = FreeLLMClient()
                print("✅ Free LLM client configured")
            else:
                # Setup OpenAI API
                api_key = os.getenv('OPENAI_API_KEY')
                if api_key:
                    self.openai_client = OpenAI(api_key=api_key)
                    print("✅ OpenAI API configured")
                else:
                    print("⚠️ OpenAI API key not found - switching to free LLM")
                    self.use_free_llm = True
                    self.free_llm_client = FreeLLMClient()

        except Exception as e:
            print(f"⚠️ API setup warning: {str(e)}")
            # Fallback to free LLM if setup fails
            if not self.free_llm_client:
                print("🔄 Falling back to free LLM...")
                self.use_free_llm = True
                self.free_llm_client = FreeLLMClient()

    def create_linkedin_post(self, prompt: str) -> Dict[str, Any]:
        """
        Generate and post LinkedIn content based on a prompt

        Args:
            prompt (str): User's description of what to post about

        Returns:
            Dict containing success status, message, content, and posting details
        """
        try:
            # Generate content using OpenAI
            content = self._generate_post_content(prompt)

            if not content:
                return {
                    'success': False,
                    'message': 'Failed to generate content',
                    'content': ''
                }

            # Attempt to post to LinkedIn (with limitations)
            post_result = self._post_to_linkedin(content)

            # Determine success based on content generation (not posting)
            success = True  # Content generation succeeded

            return {
                'success': success,
                'message': 'Content generated successfully' + (
                    ' (ready to copy and post manually)' if not post_result.get('posted', False) else ''
                ),
                'content': content,
                'posted': post_result.get('posted', False),
                'post_id': post_result.get('post_id'),
                'limitation': post_result.get('limitation'),
                'instructions': post_result.get('instructions', []),
                'content_ready': post_result.get('content_ready', True)
            }

        except Exception as e:
            return {
                'success': False,
                'message': f'Error creating post: {str(e)}',
                'content': ''
            }

    def _generate_post_content(self, prompt: str) -> str:
        """Generate LinkedIn post content using AI (OpenAI or Free LLM)"""
        try:
            system_prompt = """You are a LinkedIn content expert. Create engaging, professional LinkedIn posts that:
            - Are 100-200 words long
            - Include relevant hashtags
            - Have a professional but personable tone
            - Include a clear call-to-action or question for engagement
            - Follow LinkedIn best practices"""

            user_prompt = f"Create a LinkedIn post about: {prompt}"

            # Use free LLM if enabled or OpenAI if available
            if self.use_free_llm and self.free_llm_client:
                print("🤖 Generating content with Free LLM...")
                return self.free_llm_client.generate_content(system_prompt, user_prompt, max_tokens=300)
            elif self.openai_client:
                print("🤖 Generating content with OpenAI...")
                response = self.openai_client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=300,
                    temperature=0.7
                )
                return response.choices[0].message.content.strip()
            else:
                # Fallback content generation without AI
                return self._generate_fallback_content(prompt)

        except Exception as e:
            print(f"⚠️ AI generation failed: {str(e)}")
            return self._generate_fallback_content(prompt)

    def _generate_fallback_content(self, prompt: str) -> str:
        """Generate basic content without AI as fallback"""
        return f"""🚀 Excited to share an update!

I recently {prompt}, and it's been an incredible learning experience. The journey has taught me valuable lessons about growth, persistence, and the importance of continuous learning.

Looking forward to applying these insights and connecting with fellow professionals who share similar interests!

What's the most valuable lesson you've learned recently? Would love to hear your thoughts! 💭

#ProfessionalGrowth #Learning #LinkedIn #Career #Development"""

    def _post_to_linkedin(self, content: str) -> Dict[str, Any]:
        """Post content to LinkedIn - Note: Current linkedin-api library doesn't support posting"""
        try:
            if not self.linkedin_api:
                return {
                    'posted': False,
                    'dry_run': True,
                    'message': 'LinkedIn API not connected - cannot post content',
                    'error': 'NO_API_CONNECTION'
                }

            # IMPORTANT: The linkedin-api library (unofficial) primarily supports READ operations
            # LinkedIn's official API requires approval for posting capabilities
            # For a real implementation, you would need:
            # 1. LinkedIn Official API access with posting permissions
            # 2. Proper OAuth authentication
            # 3. Marketing API access for content posting

            print("⚠️ LinkedIn content posting is not available with current API")
            print("📝 Content generated successfully but cannot be posted automatically")
            print("💡 To post this content:")
            print("   1. Copy the generated content")
            print("   2. Go to linkedin.com")
            print("   3. Create a new post and paste the content")

            return {
                'posted': False,
                'post_id': None,
                'message': 'Content generated but cannot be posted automatically. LinkedIn API posting requires official API access.',
                'limitation': 'POSTING_NOT_SUPPORTED',
                'instructions': [
                    'Copy the generated content above',
                    'Visit linkedin.com in your browser',
                    'Click "Start a post" on your homepage',
                    'Paste the content and click "Post"'
                ],
                'content_ready': True
            }

        except Exception as e:
            return {
                'posted': False,
                'message': f'Error in posting process: {str(e)}',
                'error': 'POSTING_ERROR'
            }

    def find_jobs_and_match(self, profile: Dict[str, Any], query: str) -> Dict[str, Any]:
        """
        Search for jobs and analyze matches with user profile

        Args:
            profile (dict): User profile information
            query (str): Job search query

        Returns:
            Dict containing job search results and match analysis
        """
        try:
            # Search for jobs
            jobs = self._search_jobs(query)

            if not jobs:
                return {
                    'success': True,
                    'jobs': [],
                    'message': 'No jobs found for the given query'
                }

            print(f"🎯 Analyzing {len(jobs)} jobs for profile match...")

            # Analyze matches for each job
            analyzed_jobs = []
            for job in jobs[:5]:  # Limit to top 5 jobs
                try:
                    match_analysis = self._analyze_job_match(profile, job)
                    job['match_analysis'] = match_analysis
                except Exception as e:
                    print(f"⚠️ Job analysis failed for {job.get('title', 'Unknown')}: {str(e)}")
                    # Use fallback analysis if AI analysis fails
                    job['match_analysis'] = self._analyze_job_match_fallback(profile, job)
                analyzed_jobs.append(job)

            return {
                'success': True,
                'jobs': analyzed_jobs,
                'message': f'Found {len(analyzed_jobs)} jobs with match analysis'
            }

        except Exception as e:
            print(f"❌ Error in find_jobs_and_match: {str(e)}")
            return {
                'success': False,
                'jobs': [],
                'message': f'Error searching jobs: {str(e)}'
            }

    def _search_jobs(self, query: str) -> List[Dict[str, Any]]:
        """Search for jobs using LinkedIn API"""
        try:
            if not self.linkedin_api:
                print("⚠️ LinkedIn API not available - cannot search real jobs")
                return []

            # Parse query to extract keywords and location
            keywords, location = self._parse_job_query(query)

            print(f"🔍 Searching LinkedIn for: '{keywords}' in '{location or 'any location'}'")
             # Search using real LinkedIn API with broader search then manual filtering
            search_params = {
                'keywords': keywords,
                'limit': 5  # Reduced rate limit for testing purposes
            }

            print(f"📍 Search parameters: {search_params}")

            search_results = self.linkedin_api.search_jobs(**search_params)

            print(f"📊 Found {len(search_results)} jobs from LinkedIn API")

            # Apply manual location filtering since LinkedIn API location filtering is unreliable
            if location and location.lower() != 'any location':
                filtered_results = []
                print(f"🔍 Applying manual location filter for '{location}'...")

                for i, result in enumerate(search_results):
                    # Extract job ID for detailed lookup
                    job_id = None
                    if 'entityUrn' in result:
                        urn = result['entityUrn']
                        if ':' in urn:
                            job_id = urn.split(':')[-1]

                    if not job_id:
                        continue

                    try:
                        # Get detailed job information to check location
                        job_details = self.linkedin_api.get_job(job_id)
                        job_location = job_details.get('formattedLocation', '').lower()

                        print(f"🗺️ Job {i+1}: {result.get('title', 'Unknown')} - Location: '{job_location}'")

                        # Check if job location matches desired location (more flexible matching)
                        location_variations = self._get_location_variations(location)
                        location_match = False

                        if job_location:
                            # Check exact matches first
                            if location.lower() in job_location:
                                location_match = True
                                print(f"✅ Exact match: '{location.lower()}' found in '{job_location}'")
                            # Check variations
                            elif any(var in job_location for var in location_variations):
                                matching_var = next(var for var in location_variations if var in job_location)
                                location_match = True
                                print(f"✅ Variation match: '{matching_var}' found in '{job_location}'")
                            # Check if it's a remote job with company in target location
                            elif 'remote' in job_location:
                                # For remote jobs, be more lenient but still prefer target location
                                location_match = True
                                print(f"✅ Remote job included: '{job_location}'")

                        if location_match:
                            # Store the job with its detailed information
                            result['_job_details'] = job_details  # Cache the details
                            filtered_results.append(result)

                            if len(filtered_results) >= 10:  # Stop when we have enough matches
                                break

                    except Exception as e:
                        print(f"⚠️ Error checking job {job_id}: {str(e)}")
                        continue

                print(f"� Filtered from {len(search_results)} to {len(filtered_results)} jobs based on location")

                # If no jobs match the location filter, try a much broader search
                if len(filtered_results) == 0:
                    print(f"⚠️ No location matches found with strict filtering")
                    print(f"🔄 Trying broader keyword search...")

                    # Try searching with location in keywords
                    broader_search = self.linkedin_api.search_jobs(
                        keywords=f"{keywords} {location}",
                        limit=30
                    )

                    for result in broader_search[:5]:
                        job_id = None
                        if 'entityUrn' in result:
                            urn = result['entityUrn']
                            if ':' in urn:
                                job_id = urn.split(':')[-1]

                        if job_id:
                            try:
                                job_details = self.linkedin_api.get_job(job_id)
                                result['_job_details'] = job_details
                                filtered_results.append(result)
                            except:
                                pass

                    if len(filtered_results) == 0:
                        # Last resort: include top results with location context
                        print(f"⚠️ Still no matches, including top results with location context")
                        for result in search_results[:3]:
                            job_id = None
                            if 'entityUrn' in result:
                                urn = result['entityUrn']
                                if ':' in urn:
                                    job_id = urn.split(':')[-1]

                            if job_id:
                                try:
                                    job_details = self.linkedin_api.get_job(job_id)
                                    result['_job_details'] = job_details
                                    filtered_results.append(result)
                                except:
                                    pass

                search_results = filtered_results[:5]  # Take top 5 filtered results
            else:
                # No location filter, just get details for first few results
                for result in search_results[:5]:
                    job_id = None
                    if 'entityUrn' in result:
                        urn = result['entityUrn']
                        if ':' in urn:
                            job_id = urn.split(':')[-1]

                    if job_id:
                        try:
                            job_details = self.linkedin_api.get_job(job_id)
                            result['_job_details'] = job_details
                        except:
                            pass

            jobs = []
            for result in search_results:
                # Extract job ID from entityUrn
                job_id = None
                if 'entityUrn' in result:
                    # Extract ID from urn:li:fsd_jobPosting:1234567890
                    urn = result['entityUrn']
                    if ':' in urn:
                        job_id = urn.split(':')[-1]

                job = {
                    'title': result.get('title', 'Unknown Title'),
                    'company': 'Unknown Company',  # Will be filled from job details
                    'location': 'Unknown Location',  # Will be filled from job details
                    'job_id': job_id or 'unknown',
                    'description': '',  # Will be filled from job details
                    'tracking_urn': result.get('trackingUrn', ''),
                    'entity_urn': result.get('entityUrn', ''),
                    'apply_url': '',  # Will be filled from job details
                    'company_logo': '',  # Will be filled from job details
                    'linkedin_url': f'https://www.linkedin.com/jobs/view/{job_id}' if job_id else ''
                }

                # Use cached job details if available, otherwise fetch them
                job_details = result.get('_job_details')
                if not job_details and job_id:
                    try:
                        print(f"📋 Getting details for job: {job['title']}")
                        job_details = self.linkedin_api.get_job(job_id)
                    except Exception as e:
                        print(f"⚠️ Error getting job details: {e}")
                        job_details = {}

                if job_details:
                    # Update job with detailed information
                    job['description'] = job_details.get('description', '')
                    job['location'] = job_details.get('formattedLocation', job['location'])

                    # Extract company name from companyDetails
                    company_details = job_details.get('companyDetails', {})
                    if isinstance(company_details, dict):
                        # Navigate the nested structure
                        web_compact = company_details.get('com.linkedin.voyager.deco.jobs.web.shared.WebCompactJobPostingCompany', {})
                        if isinstance(web_compact, dict):
                            company_resolution = web_compact.get('companyResolutionResult', {})
                            if isinstance(company_resolution, dict):
                                company_name = company_resolution.get('name', job['company'])
                                job['company'] = company_name

                                # Extract company logo
                                logo_info = company_resolution.get('logo', {})
                                if isinstance(logo_info, dict):
                                    image_info = logo_info.get('image', {})
                                    if isinstance(image_info, dict):
                                        vector_image = image_info.get('com.linkedin.common.VectorImage', {})
                                        if isinstance(vector_image, dict):
                                            artifacts = vector_image.get('artifacts', [])
                                            if artifacts and len(artifacts) > 0:
                                                # Use the first (smallest) logo
                                                job['company_logo'] = f"https://media.licdn.com/dms/image/{artifacts[0].get('fileIdentifyingUrlPathSegment', '')}"

                    # Extract apply URL
                    apply_method = job_details.get('applyMethod', {})
                    if isinstance(apply_method, dict):
                        offsite_apply = apply_method.get('com.linkedin.voyager.jobs.OffsiteApply', {})
                        if isinstance(offsite_apply, dict):
                            apply_url = offsite_apply.get('companyApplyUrl', '')
                            if apply_url:
                                job['apply_url'] = apply_url

                    # Additional job info
                    job['remote_allowed'] = job_details.get('workRemoteAllowed', False)
                    job['workplace_types'] = job_details.get('workplaceTypes', [])
                    job['listed_at'] = job_details.get('listedAt', 0)

                # Add match analysis
                user_profile = {
                    'name': 'Arjun Sharma',
                    'title': 'ML Engineer',
                    'skills': ['Python', 'Machine Learning', 'Deep Learning', 'LLM', 'Transformers', 'PyTorch', 'TensorFlow', 'NLP'],
                    'experience': '3',
                    'location': location or 'Bangalore, India'
                }
                job['match_analysis'] = self._analyze_job_match(user_profile, job)

                jobs.append(job)

            return jobs

        except Exception as e:
            print(f"❌ LinkedIn job search failed: {str(e)}")
            # Don't return empty - let the caller handle this
            return []

    def _parse_job_query(self, query: str) -> tuple:
        """Parse job search query to extract keywords and location"""
        import re

        query_lower = query.lower()
        original_query = query

        # Major cities and locations (sorted by length to match longer names first)
        major_locations = [
            'san francisco', 'new york city', 'new york', 'los angeles',
            'washington dc', 'san jose', 'san diego', 'silicon valley',
            'bangalore', 'mumbai', 'new delhi', 'delhi', 'hyderabad',
            'pune', 'chennai', 'kolkata', 'gurgaon', 'noida',
            'london', 'paris', 'berlin', 'amsterdam', 'toronto',
            'vancouver', 'sydney', 'melbourne', 'singapore',
            'seattle', 'boston', 'chicago', 'austin', 'denver',
            'atlanta', 'miami', 'philadelphia', 'phoenix'
        ]

        location = None
        keywords = original_query

        # Method 1: Look for "in [location]" or "at [location]" patterns with proper boundaries
        for loc in sorted(major_locations, key=len, reverse=True):
            # Try pattern like "jobs in San Francisco" or "engineer at Seattle"
            pattern = rf'\b(?:in|at)\s+{re.escape(loc)}\b'
            if re.search(pattern, query_lower):
                location = loc
                # Remove the entire "in/at location" phrase from keywords
                keywords = re.sub(pattern, '', original_query, flags=re.IGNORECASE).strip()
                break

        # Method 2: Look for standalone location names (only if no location found yet)
        if not location:
            for loc in sorted(major_locations, key=len, reverse=True):
                if re.search(rf'\b{re.escape(loc)}\b', query_lower):
                    location = loc
                    # Remove location from keywords (case insensitive)
                    keywords = re.sub(rf'\b{re.escape(loc)}\b', '', original_query, flags=re.IGNORECASE).strip()
                    break

        # Method 3: Check for "remote" keyword
        if not location and re.search(r'\bremote\b', query_lower):
            location = 'remote'
            keywords = re.sub(r'\bremote\b', '', original_query, flags=re.IGNORECASE).strip()

        # Clean up keywords - remove extra spaces and common words
        keywords = re.sub(r'\s+', ' ', keywords)  # Multiple spaces to single
        keywords = re.sub(r'\b(?:jobs?|positions?|openings?|opportunities?|find|me|a)\b', '', keywords, flags=re.IGNORECASE)
        keywords = keywords.strip()

        # If keywords is empty, use job-related terms
        if not keywords:
            keywords = "ML engineer"

        return keywords, location

    def _get_demo_jobs(self, query: str) -> List[Dict[str, Any]]:
        """Return demo jobs when API is not available"""
        demo_jobs = [
            {
                'title': f'Senior {query.title()} Engineer',
                'company': 'TechCorp Solutions',
                'location': 'Bangalore, India',
                'job_id': 'demo_job_1',
                'description': f'We are looking for an experienced {query} professional to join our dynamic team. Must have 3+ years experience in {query} and related technologies.'
            },
            {
                'title': f'{query.title()} Specialist',
                'company': 'InnovateTech',
                'location': 'Mumbai, India',
                'job_id': 'demo_job_2',
                'description': f'Exciting opportunity for a {query} specialist. Work with cutting-edge technology and grow your career with us.'
            },
            {
                'title': f'Lead {query.title()} Developer',
                'company': 'StartupXYZ',
                'location': 'Remote',
                'job_id': 'demo_job_3',
                'description': f'Join our startup as a lead {query} developer. Flexible remote work, competitive salary, and equity options.'
            },
            {
                'title': f'Junior {query.title()} Analyst',
                'company': 'DataDriven Inc',
                'location': 'Hyderabad, India',
                'job_id': 'demo_job_4',
                'description': f'Entry-level position for {query} enthusiasts. We provide training and mentorship for career growth.'
            },
            {
                'title': f'{query.title()} Consultant',
                'company': 'Consulting Pro',
                'location': 'Delhi, India',
                'job_id': 'demo_job_5',
                'description': f'Independent {query} consultant role with flexible hours and project-based work.'
            }
        ]

        return demo_jobs[:5]

    def _analyze_job_match(self, profile: Dict[str, Any], job: Dict[str, Any]) -> str:
        """Analyze how well a job matches the user profile"""
        try:
            # Create analysis prompt
            profile_text = f"""
            Name: {profile.get('name', 'N/A')}
            Current Title: {profile.get('title', 'N/A')}
            Skills: {', '.join(profile.get('skills', []))}
            Experience: {profile.get('experience', 'N/A')} years
            Preferred Location: {profile.get('location', 'N/A')}
            """

            job_description = job.get('description', 'N/A')
            # Safely handle description that might not be a string
            if not isinstance(job_description, str):
                job_description = str(job_description) if job_description else 'N/A'

            if isinstance(job_description, str) and len(job_description) > 500:
                job_description = job_description[:500] + "..."

            job_text = f"""
            Job Title: {job.get('title', 'N/A')}
            Company: {job.get('company', 'N/A')}
            Location: {job.get('location', 'N/A')}
            Description: {job_description}
            """

            analysis_prompt = f"""Analyze how well this profile matches this job. Be concise and specific.
            
            PROFILE:
            {profile_text}
            
            JOB:
            {job_text}
            
            Provide a brief analysis (2-3 sentences) covering:
            1. Match strength (Strong/Good/Moderate/Weak)
            2. Key matching points
            3. Any gaps or concerns
            
            Keep it under 100 words."""

            # Use free LLM if enabled or OpenAI if available
            if self.use_free_llm and self.free_llm_client:
                return self.free_llm_client.generate_content(
                    "You are a job matching expert. Analyze job-candidate fit accurately.",
                    analysis_prompt,
                    max_tokens=150
                )
            elif self.openai_client:
                response = self.openai_client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "user", "content": analysis_prompt}
                    ],
                    max_tokens=150,
                    temperature=0.3
                )
                return response.choices[0].message.content.strip()
            else:
                return self._analyze_job_match_fallback(profile, job)

        except Exception as e:
            print(f"⚠️ AI analysis failed: {str(e)}")
            return self._analyze_job_match_fallback(profile, job)

    def _analyze_job_match_fallback(self, profile: Dict[str, Any], job: Dict[str, Any]) -> str:
        """Fallback job match analysis without AI"""
        # Simple rule-based matching
        user_skills = [skill.lower() for skill in profile.get('skills', [])]
        job_title = str(job.get('title', '')).lower()

        # Safely get job description as string
        job_desc_raw = job.get('description', '')
        if isinstance(job_desc_raw, str):
            job_desc = job_desc_raw.lower()
        else:
            job_desc = str(job_desc_raw).lower() if job_desc_raw else ""

        # Check skill matches
        skill_matches = 0
        for skill in user_skills:
            if skill in job_title or skill in job_desc:
                skill_matches += 1

        # Check location preference
        user_location = profile.get('location', '').lower()
        job_location = job.get('location', '').lower()
        location_match = (user_location in job_location or
                         job_location in user_location or
                         'remote' in job_location)

        # Generate analysis
        if skill_matches >= 2 and location_match:
            strength = "Strong"
        elif skill_matches >= 1 and location_match:
            strength = "Good"
        elif skill_matches >= 1 or location_match:
            strength = "Moderate"
        else:
            strength = "Weak"

        analysis = f"{strength} match. "

        if skill_matches > 0:
            analysis += f"Found {skill_matches} relevant skill(s) in job requirements. "

        if location_match:
            analysis += "Location preference aligns well. "
        elif not location_match:
            analysis += "Location might require consideration. "

        if skill_matches == 0:
            analysis += "Consider developing relevant skills mentioned in the job description."

        return analysis

    def _get_location_urn(self, location: str) -> Optional[str]:
        """Get LinkedIn location URN for better search filtering"""
        # Common location URNs for LinkedIn API
        location_urns = {
            'san francisco': 'urn:li:geo:90009496',
            'san francisco bay area': 'urn:li:geo:90009496',
            'new york': 'urn:li:geo:105080838',
            'new york city': 'urn:li:geo:105080838',
            'seattle': 'urn:li:geo:105809844',
            'boston': 'urn:li:geo:105057022',
            'chicago': 'urn:li:geo:104769905',
            'austin': 'urn:li:geo:106835970',
            'los angeles': 'urn:li:geo:90009714',
            'bangalore': 'urn:li:geo:106215760',
            'mumbai': 'urn:li:geo:105214831',
            'delhi': 'urn:li:geo:106215729',
            'hyderabad': 'urn:li:geo:106215727'
        }
        return location_urns.get(location.lower())

    def _get_location_variations(self, location: str) -> List[str]:
        """Get variations of location names for better matching"""
        variations = {
            'san francisco': ['san francisco', 'sf', 'bay area', 'san francisco bay area'],
            'new york': ['new york', 'ny', 'nyc', 'new york city'],
            'seattle': ['seattle', 'wa', 'washington'],
            'boston': ['boston', 'ma', 'massachusetts'],
            'chicago': ['chicago', 'il', 'illinois'],
            'austin': ['austin', 'tx', 'texas'],
            'los angeles': ['los angeles', 'la', 'california'],
            'bangalore': ['bangalore', 'bengaluru', 'karnataka'],
            'mumbai': ['mumbai', 'maharashtra'],
            'delhi': ['delhi', 'new delhi'],
            'hyderabad': ['hyderabad', 'telangana']
        }
        return variations.get(location.lower(), [location.lower()])

    # Chrome Extension Features

    def get_user_profile(self) -> Dict[str, Any]:
        """Get current user's LinkedIn profile"""
        try:
            if not self.linkedin_api:
                return {
                    'success': False,
                    'error': 'LinkedIn API not connected'
                }

            # Get user's profile
            profile = self.linkedin_api.get_profile()

            return {
                'success': True,
                'profile': {
                    'name': f"{profile.get('firstName', '')} {profile.get('lastName', '')}".strip(),
                    'title': profile.get('headline', ''),
                    'company': profile.get('experience', [{}])[0].get('companyName', '') if profile.get('experience') else '',
                    'location': profile.get('locationName', ''),
                    'skills': [skill.get('name', '') for skill in profile.get('skills', [])[:10]],
                    'bio': profile.get('summary', ''),
                    'profile_picture': profile.get('displayPictureUrl', ''),
                    'connections': profile.get('numConnections', 0),
                    'public_id': profile.get('publicIdentifier', '')
                }
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"Failed to get profile: {str(e)}"
            }

    def get_profile_info(self) -> Dict[str, Any]:
        """Get profile information for session storage"""
        try:
            user_profile = self.get_user_profile()
            if user_profile['success']:
                profile_data = user_profile['profile']
                return {
                    'name': profile_data.get('name', 'User'),
                    'title': profile_data.get('title', 'Professional'),
                    'company': profile_data.get('company', 'Company'),
                    'location': profile_data.get('location', 'Location'),
                    'skills': profile_data.get('skills', []),
                    'bio': profile_data.get('bio', ''),
                    'avatar': profile_data.get('profile_picture', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'),
                    'connections': profile_data.get('connections', 0),
                    'experience': '2+',  # Default experience
                    'public_id': profile_data.get('public_id', '')
                }
            else:
                # Return default profile if API fails
                return {
                    'name': 'Arjun Sharma',
                    'title': 'ML Engineer',
                    'company': 'TechCorp India',
                    'location': 'Bangalore, India',
                    'skills': ['Python', 'Machine Learning', 'Deep Learning', 'LLM', 'Transformers', 'PyTorch', 'TensorFlow', 'NLP'],
                    'bio': 'Passionate ML engineer with expertise in LLMs, NLP, and AI research. Building next-generation AI solutions.',
                    'avatar': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
                    'connections': 0,
                    'experience': '3+',
                    'public_id': ''
                }
        except Exception as e:
            print(f"❌ Error getting profile info: {str(e)}")
            # Return fallback profile
            return {
                'name': 'Arjun Sharma',
                'title': 'ML Engineer',
                'company': 'TechCorp India',
                'location': 'Bangalore, India',
                'skills': ['Python', 'Machine Learning', 'Deep Learning', 'LLM', 'Transformers', 'PyTorch', 'TensorFlow', 'NLP'],
                'bio': 'Passionate ML engineer with expertise in LLMs, NLP, and AI research. Building next-generation AI solutions.',
                'avatar': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
                'connections': 0,
                'experience': '3+',
                'public_id': ''
            }

    def analyze_trending_posts(self, topic: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Analyze trending LinkedIn posts for a given topic"""
        try:
            if not self.linkedin_api:
                return self._get_mock_trends(topic)

            # Search for posts about the topic
            search_results = self.linkedin_api.search_posts(topic, limit=limit)

            trends = []
            for post in search_results:
                trend_data = {
                    'content': post.get('commentary', {}).get('text', ''),
                    'likes': post.get('socialDetail', {}).get('totalSocialActivityCounts', {}).get('numLikes', 0),
                    'comments': post.get('socialDetail', {}).get('totalSocialActivityCounts', {}).get('numComments', 0),
                    'shares': post.get('socialDetail', {}).get('totalSocialActivityCounts', {}).get('numShares', 0),
                    'author': post.get('author', {}).get('name', ''),
                    'post_url': post.get('permalink', ''),
                    'hashtags': self._extract_hashtags(post.get('commentary', {}).get('text', '')),
                    'engagement_rate': self._calculate_engagement_rate(post),
                    'post_time': post.get('createdAt', ''),
                    'topic_relevance': self._calculate_topic_relevance(post.get('commentary', {}).get('text', ''), topic)
                }
                trends.append(trend_data)

            # Sort by engagement rate
            trends.sort(key=lambda x: x['engagement_rate'], reverse=True)
            return trends[:limit]

        except Exception as e:
            print(f"Error analyzing trends: {e}")
            return self._get_mock_trends(topic)

    def _get_mock_trends(self, topic: str) -> List[Dict[str, Any]]:
        """Get mock trending data when API is not available"""
        mock_trends = [
            {
                'content': f"Excited to share insights about {topic}! The future is bright 🚀",
                'likes': 245,
                'comments': 32,
                'shares': 18,
                'author': 'Industry Expert',
                'post_url': 'https://linkedin.com/posts/example1',
                'hashtags': ['#innovation', '#technology', '#future'],
                'engagement_rate': 0.12,
                'post_time': '2024-01-15T10:30:00Z',
                'topic_relevance': 0.9
            },
            {
                'content': f"Key trends in {topic} that every professional should know 💡",
                'likes': 189,
                'comments': 24,
                'shares': 15,
                'author': 'Thought Leader',
                'post_url': 'https://linkedin.com/posts/example2',
                'hashtags': ['#leadership', '#growth', '#trends'],
                'engagement_rate': 0.1,
                'post_time': '2024-01-14T15:45:00Z',
                'topic_relevance': 0.85
            }
        ]
        return mock_trends

    def _extract_hashtags(self, text: str) -> List[str]:
        """Extract hashtags from post text"""
        import re
        hashtags = re.findall(r'#\w+', text)
        return hashtags

    def _calculate_engagement_rate(self, post: Dict[str, Any]) -> float:
        """Calculate engagement rate for a post"""
        social_counts = post.get('socialDetail', {}).get('totalSocialActivityCounts', {})
        likes = social_counts.get('numLikes', 0)
        comments = social_counts.get('numComments', 0)
        shares = social_counts.get('numShares', 0)

        total_engagement = likes + (comments * 2) + (shares * 3)  # Weight comments and shares higher

        # Estimate follower count for calculation (would need actual follower data)
        estimated_reach = max(total_engagement * 10, 1000)  # Rough estimation

        return total_engagement / estimated_reach

    def _calculate_topic_relevance(self, text: str, topic: str) -> float:
        """Calculate how relevant a post is to the given topic"""
        text_lower = text.lower()
        topic_lower = topic.lower()

        # Simple relevance calculation based on keyword matches
        topic_words = topic_lower.split()
        text_words = text_lower.split()

        matches = sum(1 for word in topic_words if word in text_words)
        return matches / len(topic_words) if topic_words else 0

    def optimize_post_content(self, content: Dict[str, Any], trends: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Optimize post content based on trending analysis"""
        try:
            original_content = content.get('text', '')

            # Analyze trends to extract insights
            insights = self._analyze_trend_insights(trends)

            # Generate optimized content using AI
            if self.use_free_llm and self.free_llm_client:
                optimized = self.free_llm_client.optimize_linkedin_post(original_content, insights)
            elif self.openai_client:
                optimized = self._optimize_with_openai(original_content, insights)
            else:
                optimized = self._optimize_with_templates(original_content, insights)

            return {
                'original_content': original_content,
                'optimized_content': optimized.get('content', original_content),
                'suggested_hashtags': optimized.get('hashtags', []),
                'optimal_posting_time': optimized.get('posting_time', 'Best times: 8-10 AM, 12-2 PM, 5-6 PM on weekdays'),
                'engagement_predictions': optimized.get('engagement_predictions', {}),
                'content_insights': insights,
                'improvements_made': optimized.get('improvements', [])
            }

        except Exception as e:
            return {
                'original_content': content.get('text', ''),
                'optimized_content': content.get('text', ''),
                'error': f"Optimization failed: {str(e)}",
                'suggested_hashtags': ['#professional', '#linkedin'],
                'optimal_posting_time': 'Best times: 8-10 AM, 12-2 PM, 5-6 PM on weekdays'
            }

    def _analyze_trend_insights(self, trends: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze trends to extract actionable insights"""
        if not trends:
            return {
                'top_hashtags': ['#professional', '#linkedin'],
                'average_engagement': 0.05,
                'common_themes': [],
                'optimal_length': 150
            }

        # Extract top hashtags
        all_hashtags = []
        for trend in trends:
            all_hashtags.extend(trend.get('hashtags', []))

        hashtag_counts = {}
        for hashtag in all_hashtags:
            hashtag_counts[hashtag] = hashtag_counts.get(hashtag, 0) + 1

        top_hashtags = sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        top_hashtags = [hashtag[0] for hashtag in top_hashtags]

        # Calculate average engagement
        avg_engagement = sum(trend.get('engagement_rate', 0) for trend in trends) / len(trends)

        # Analyze content length
        lengths = [len(trend.get('content', '')) for trend in trends if trend.get('content')]
        optimal_length = sum(lengths) // len(lengths) if lengths else 150

        return {
            'top_hashtags': top_hashtags,
            'average_engagement': avg_engagement,
            'optimal_length': optimal_length,
            'total_trends_analyzed': len(trends)
        }

    def _optimize_with_openai(self, content: str, insights: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize content using OpenAI"""
        try:
            prompt = f"""
            Optimize this LinkedIn post for maximum engagement based on trending insights:
            
            Original content: {content}
            
            Trending insights:
            - Top hashtags: {insights.get('top_hashtags', [])}
            - Average engagement: {insights.get('average_engagement', 0)}
            - Optimal length: {insights.get('optimal_length', 150)} characters
            
            Please provide:
            1. Optimized content that maintains the original message but improves engagement
            2. 3-5 relevant hashtags
            3. Brief explanation of improvements made
            
            Format as JSON with keys: content, hashtags, improvements
            """

            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7
            )

            result = json.loads(response.choices[0].message.content)
            return result

        except Exception as e:
            return self._optimize_with_templates(content, insights)

    def _optimize_with_templates(self, content: str, insights: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize content using template-based approach"""
        # Basic optimization using templates
        optimized_content = content

        # Add emoji if not present
        if '📍' not in content and '🚀' not in content and '💡' not in content:
            optimized_content = f"💡 {optimized_content}"

        # Ensure call to action
        if not any(phrase in content.lower() for phrase in ['thoughts?', 'what do you think', 'share your', 'comment']):
            optimized_content += "\n\nWhat are your thoughts? Share in the comments! 👇"

        # Use trending hashtags
        suggested_hashtags = insights.get('top_hashtags', ['#professional', '#linkedin', '#growth'])

        return {
            'content': optimized_content,
            'hashtags': suggested_hashtags[:5],
            'improvements': [
                'Added engaging emoji',
                'Included call-to-action',
                'Optimized hashtags based on trends'
            ],
            'posting_time': 'Best times: 8-10 AM, 12-2 PM, 5-6 PM on weekdays'
        }

    def analyze_profile_insights(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze LinkedIn profile and provide insights for improvement"""
        try:
            insights = {
                'profile_completeness': self._calculate_profile_completeness(profile_data),
                'content_suggestions': self._get_content_suggestions(profile_data),
                'network_growth_tips': self._get_network_tips(profile_data),
                'skill_recommendations': self._get_skill_recommendations(profile_data),
                'headline_optimization': self._optimize_headline(profile_data.get('headline', '')),
                'engagement_opportunities': self._find_engagement_opportunities(profile_data)
            }

            return insights

        except Exception as e:
            return {
                'error': f"Profile analysis failed: {str(e)}",
                'profile_completeness': 0.7,
                'content_suggestions': ['Share more about your professional journey'],
                'network_growth_tips': ['Connect with industry professionals']
            }

    def _calculate_profile_completeness(self, profile_data: Dict[str, Any]) -> float:
        """Calculate profile completeness score"""
        required_fields = ['name', 'headline', 'summary', 'experience', 'skills', 'profile_picture']
        completed_fields = sum(1 for field in required_fields if profile_data.get(field))
        return completed_fields / len(required_fields)

    def _get_content_suggestions(self, profile_data: Dict[str, Any]) -> List[str]:
        """Get personalized content suggestions based on profile"""
        suggestions = []

        title = profile_data.get('headline', '').lower()
        company = profile_data.get('company', '').lower()

        if 'engineer' in title or 'developer' in title:
            suggestions.extend([
                'Share a technical challenge you recently solved',
                'Post about a new technology you\'re learning',
                'Write about best practices in software development'
            ])
        elif 'manager' in title or 'lead' in title:
            suggestions.extend([
                'Share leadership insights from your experience',
                'Post about team building strategies',
                'Write about effective project management'
            ])
        else:
            suggestions.extend([
                'Share insights from your industry',
                'Post about professional growth tips',
                'Write about your latest project achievements'
            ])

        return suggestions[:5]

    def _get_network_tips(self, profile_data: Dict[str, Any]) -> List[str]:
        """Get network growth tips"""
        return [
            'Connect with colleagues from current and past companies',
            'Engage with posts from your industry leaders',
            'Join LinkedIn groups related to your field',
            'Comment thoughtfully on relevant posts',
            'Share valuable content regularly'
        ]

    def _get_skill_recommendations(self, profile_data: Dict[str, Any]) -> List[str]:
        """Get skill recommendations based on profile"""
        current_skills = [skill.lower() for skill in profile_data.get('skills', [])]
        title = profile_data.get('headline', '').lower()

        if 'engineer' in title or 'developer' in title:
            recommended = ['cloud computing', 'machine learning', 'devops', 'kubernetes', 'docker']
        elif 'manager' in title:
            recommended = ['project management', 'agile methodology', 'leadership', 'strategic planning']
        elif 'marketing' in title:
            recommended = ['digital marketing', 'analytics', 'content strategy', 'seo', 'social media']
        else:
            recommended = ['communication', 'leadership', 'problem solving', 'teamwork']

        # Filter out skills already present
        new_skills = [skill for skill in recommended if skill not in current_skills]
        return new_skills[:3]

    def _optimize_headline(self, current_headline: str) -> Dict[str, Any]:
        """Provide headline optimization suggestions"""
        if not current_headline:
            return {
                'current': '',
                'suggestions': ['Add a compelling headline that describes your expertise'],
                'tips': ['Include keywords relevant to your industry', 'Mention your value proposition']
            }

        suggestions = []
        tips = []

        if len(current_headline) < 50:
            suggestions.append('Consider expanding your headline to use more of the 220 character limit')
            tips.append('Include specific skills or achievements')

        if '|' not in current_headline and 'at' not in current_headline.lower():
            suggestions.append('Consider mentioning your company or industry')
            tips.append('Format: "Role | Company" or "Role at Company"')

        return {
            'current': current_headline,
            'suggestions': suggestions,
            'tips': tips
        }

    def _find_engagement_opportunities(self, profile_data: Dict[str, Any]) -> List[str]:
        """Find opportunities to increase profile engagement"""
        opportunities = [
            'Post regular updates about your professional journey',
            'Share industry insights and trends',
            'Celebrate team achievements and milestones',
            'Comment on posts from your network',
            'Share relevant articles with your perspective'
        ]

        # Customize based on profile
        if profile_data.get('connections', 0) < 500:
            opportunities.insert(0, 'Focus on growing your network to 500+ connections')

        return opportunities[:5]

    def create_post(self, content: str) -> Dict[str, Any]:
        """Create and publish a LinkedIn post"""
        try:
            if not self.linkedin_api:
                return {
                    'success': False,
                    'error': 'LinkedIn API not connected',
                    'content': content,
                    'posted': False
                }

            # Post to LinkedIn
            post_urn = self.linkedin_api.post_update(text=content)

            return {
                'success': True,
                'content': content,
                'posted': True,
                'post_id': post_urn,
                'message': 'Post published successfully!'
            }

        except Exception as e:
            return {
                'success': False,
                'error': f"Failed to post: {str(e)}",
                'content': content,
                'posted': False
            }
