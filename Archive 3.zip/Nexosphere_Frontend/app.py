"""
LinkedIn Assistant Web Interface & Chrome Extension Backend
A Flask-based web application that provides APIs for both web and Chrome extension interfaces
"""

from flask import Flask, render_template, request, jsonify, session, redirect
from flask_cors import CORS
import re
import os
import json
import uuid
from datetime import datetime, timedelta
from linkedin_assistant import LinkedInAssistant
from dotenv import load_dotenv
from free_llm_client import FreeLLMClient
import requests # Add this import

# Load environment variables
load_dotenv()

# Define the backend API URL
BACKEND_API_URL = os.getenv("BACKEND_API_URL", "http://127.0.0.1:8080")


app = Flask(__name__)
app.secret_key = os.urandom(24)
app.permanent_session_lifetime = timedelta(hours=24)  # Sessions last 24 hours

# Session configuration for better reliability
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = False  # Set to True for HTTPS in production

# Enable CORS for Chrome extension
CORS(app, origins=["chrome-extension://*", "http://localhost:*"], supports_credentials=True)

# Global assistant instance
assistant = None

def get_assistant():
    """Get or create LinkedIn assistant instance"""
    global assistant
    if not assistant:
        try:
            print("🤖 Initializing LinkedIn Assistant...")
            assistant = LinkedInAssistant()
            print("✅ LinkedIn Assistant initialized successfully")
        except Exception as e:
            print(f"❌ Failed to initialize LinkedIn Assistant: {str(e)}")
            import traceback
            traceback.print_exc()
            # Return None to indicate failure
            return None
    return assistant

def get_assistant_with_session():
    """Get LinkedIn assistant with session credentials"""
    global assistant

    # If we have session credentials, use them
    if 'linkedin_username' in session and 'linkedin_password' in session:
        if not assistant:
            try:
                print("🔐 Creating LinkedIn Assistant with session credentials...")
                assistant = LinkedInAssistant(
                    email=session['linkedin_username'],
                    password=session['linkedin_password']
                )
                print("✅ LinkedIn Assistant created with session credentials")
            except Exception as e:
                print(f"❌ Failed to create assistant with session credentials: {str(e)}")
                return None
    else:
        # Fall back to environment variables
        assistant = get_assistant()

    return assistant

def handle_discussion_forum(usermessage):
    """
    Handle discussion forum requests by asking for confirmation before redirecting
    to the LinkedIn Forums AI platform.
    """

    return {
        'message': f"🗣️ **Perfect! This is a great topic for community discussion.**\n\n"
                  f"I think this would be ideal for our **LinkedIn Forums AI** platform where you can:\n\n"
                  f"💬 **Engage with professionals** in meaningful discussions\n"
                  f"🧠 **Get diverse perspectives** from industry experts\n"
                  f"🤝 **Build connections** through thoughtful conversations\n"
                  f"📈 **Share insights** and learn from the community\n\n"
                  f"**Would you like me to redirect you to the LinkedIn Forums AI platform?**\n\n"
                  f"Please respond with:\n"
                  f"• **Yes** - Take me to the forums\n"
                  f"• **No** - Continue our conversation here\n\n"
                  f"💡 *The forums are specifically designed for professional discussions like yours!*",
        'data': {
            'type': 'forum_confirmation',
            'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
            'action': 'ask_forum_confirmation',
            'original_message': usermessage,
            'awaiting_confirmation': True
        }
    }

def get_user_profile():
    """Get user profile from session or use mock data"""
    print(f"🔍 get_user_profile() called. Session keys: {list(session.keys())}")
    if 'user_profile' in session:
        profile_data = session['user_profile']
        print(f"✅ Found user_profile in session: {profile_data.get('name', 'NO_NAME')}")
        print(f"🔍 Session profile data: {profile_data}")
        return profile_data
    else:
        print("❌ No user_profile in session, using mock data")
        # Return mock profile if no session data
        return MOCK_PROFILE

# Mock user profile - In a real app, this would come from LinkedIn OAuth
MOCK_PROFILE = {
    'name': 'Arjun Sharma',
    'title': 'ML Engineer',
    'company': 'TechCorp India',
    'location': 'Bangalore, India',
    'skills': ['Python', 'Machine Learning', 'Deep Learning', 'LLM', 'Transformers', 'PyTorch', 'TensorFlow', 'NLP'],
    'experience': '3',
    'bio': 'Passionate ML engineer with expertise in LLMs, NLP, and AI research. Building next-generation AI solutions and contributing to open-source ML projects.',
    'avatar': 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
}

def initialize_session():
    """Initialize session with chat history"""
    if 'chat_history' not in session:
        session['chat_history'] = []
        session['session_id'] = str(uuid.uuid4())

        # Get user profile (from session or mock)
        user_profile = get_user_profile()
        user_name = user_profile.get('name', 'User')

        # Add welcome message
        session['chat_history'].append({
            'type': 'assistant',
            'message': f"Hi {user_name}! 👋 I'm your LinkedIn AI Assistant. I can help you with:\n\n📝 **Content Creation** - Generate professional posts\n🔍 **Job Search** - Find and analyze job matches\n\nWhat would you like to do today?",
            'timestamp': datetime.now().isoformat()
        })

def detect_intent(message):
    """
    Detect user intent from the message using LLM.
    Falls back to keyword-based detection if LLM is unavailable or returns an invalid result.
    """
    try:
        llm_client = FreeLLMClient()
    except Exception as e:
        llm_client = None

    if not llm_client:
        return detect_intent_fallback(message)

    system_prompt = (
        "You are an expert intent classifier for LinkedIn assistant interactions. "
        "Classify the user's message into exactly ONE of these 6 intent categories:\n"
        "1. post_analysis - User wants to analyze existing LinkedIn posts, content performance, or engagement metrics\n"
        "2. referal_request - User is asking for job referrals, recommendations, or connections to specific people/companies\n"
        "3. discussion_forum - User wants to engage in discussions, ask questions to the community, or participate in forums\n"
        "4. content_creation - User wants to create, write, or generate LinkedIn posts or professional content\n"
        "5. job_search - User wants to search for jobs, career opportunities, or get career advice\n"
        "6. general_query - General questions or anything that doesn't fit the other categories\n"
        "Respond with ONLY the intent category name (e.g., 'job_search'), nothing else."
    )
    user_prompt = f"Classify this message: '{message}'"
    valid_intents = [
        'post_analysis',
        'referal_request',
        'discussion_forum',
        'content_creation',
        'job_search',
        'general_query'
    ]

    try:
        intent = llm_client.generate_content(system_prompt, user_prompt, max_tokens=10)
        intent = intent.strip().lower()
        if intent in valid_intents:
            return intent
        else:
            return detect_intent_fallback(message)
    except Exception as e:
        return detect_intent_fallback(message)

def detect_intent_fallback(message):
    """
    Fallback intent detection using keywords when LLM is unavailable.
    """
    message_lower = message.lower()
    if any(keyword in message_lower for keyword in ['analyze', 'analysis', 'performance', 'metrics', 'engagement', 'views', 'likes', 'comments', 'trending', 'viral']):
        return 'post_analysis'
    elif any(keyword in message_lower for keyword in ['referral', 'refer', 'recommendation', 'connect me', 'introduce', 'know someone', 'contact at']):
        return 'referal_request'
    elif any(keyword in message_lower for keyword in ['discuss', 'question', 'thoughts', 'opinion', 'what do you think', 'community', 'forum', 'debate']):
        return 'discussion_forum'
    elif any(keyword in message_lower for keyword in ['write', 'create', 'post about', 'share about', 'help me write', 'generate', 'draft', 'compose', 'announce']):
        return 'content_creation'
    elif any(keyword in message_lower for keyword in ['job', 'career', 'position', 'role', 'opportunity', 'hire', 'work', 'employment', 'search']):
        return 'job_search'
    else:
        return 'general_query'
def extract_content_prompt(message):
    """Extract the content topic from user message"""
    # Remove common prefixes
    prefixes = [
        'help me write a post about',
        'create a post about',
        'i want to post about',
        'write about',
        'post about',
        'share about',
        'i want to share',
        'help me announce',
        'create content about'
    ]

    message_lower = message.lower()
    for prefix in prefixes:
        if prefix in message_lower:
            return message_lower.replace(prefix, '').strip()

    return message

def extract_job_query(message):
    """Extract job search query from user message"""
    # Remove common prefixes
    prefixes = [
        'find me jobs',
        'search for jobs',
        'look for jobs',
        'find jobs',
        'search jobs',
        'looking for',
        'find me',
        'search for'
    ]

    message_lower = message.lower()
    for prefix in prefixes:
        if prefix in message_lower:
            return message_lower.replace(prefix, '').strip()

    return message

@app.route('/login')
def login():
    """Login page for LinkedIn credentials"""
    return render_template('login.html')

@app.route('/api/login', methods=['POST'])
def api_login():
    """Handle login by calling the backend API."""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    if not username or not password:
        return jsonify({'success': False, 'error': 'Username and password are required'}), 400

    try:
        print(f"🔐 Attempting login for: {username} via backend API")

        # Call the FastAPI backend
        api_url = f"{BACKEND_API_URL}/api/login"
        response = requests.post(api_url, json={"email": username, "password": password})

        # Raise an exception for bad status codes (4xx or 5xx)
        response.raise_for_status()

        profile_info = response.json()
        print(f"✅ Profile info loaded from backend: {profile_info.get('name', 'Unknown')}")

        # Clear any existing session data first
        session.clear()

        # Store credentials and profile in session
        session['linkedin_username'] = username
        session['linkedin_password'] = password # Note: Storing password in session is not recommended for production
        session['user_profile'] = profile_info
        session['linkedin_connected'] = True
        session.permanent = True

        session.modified = True

        print(f"✅ Session data stored: {list(session.keys())}")

        return jsonify({
            'success': True,
            'user_info': profile_info,
            'message': 'Successfully connected to LinkedIn via backend',
            'session_id': session.get('session_id', 'new')
        })

    except requests.exceptions.RequestException as e:
        print(f"❌ Backend API login failed: {str(e)}")
        error_message = "Failed to connect to the backend service."
        if e.response is not None:
            try:
                error_detail = e.response.json().get('detail', str(e))
                error_message = f"API Error: {error_detail}"
            except json.JSONDecodeError:
                error_message = f"API Error: {e.response.text}"

        return jsonify({
            'success': False,
            'error': error_message
        }), 500
    except Exception as e:
        print(f"❌ An unexpected error occurred during login: {str(e)}")
        return jsonify({
            'success': False,
            'error': f'An unexpected error occurred: {str(e)}'
        }), 500

@app.route('/api/logout', methods=['POST'])
def api_logout():
    """Handle logout"""
    session.clear()
    global assistant
    assistant = None
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/session-status')
def session_status():
    """Debug route to check session status"""
    return jsonify({
        'session_keys': list(session.keys()),
        'linkedin_connected': session.get('linkedin_connected'),
        'has_user_profile': 'user_profile' in session,
        'session_id': session.get('session_id')
    })

@app.route('/chat')
def chat_interface():
    """Chat interface (requires login)"""
    print(f"🔍 Chat route accessed. Session keys: {list(session.keys())}")
    print(f"🔍 LinkedIn connected: {session.get('linkedin_connected')}")

    if not session.get('linkedin_connected'):
        print("❌ No LinkedIn connection found, redirecting to login")
        return redirect('/login')

    print("✅ LinkedIn connection verified, showing chat interface")
    initialize_session()
    user_profile = get_user_profile()
    print(f"🔍 User profile being passed to template: {user_profile.get('name', 'NO_NAME')} - {user_profile.get('title', 'NO_TITLE')}")
    print(f"🔍 Complete profile data: {user_profile}")
    return render_template('chat.html', profile=user_profile)

@app.route('/')
def index():
    """Main route - redirect to login if not authenticated"""
    if not session.get('linkedin_connected'):
        return redirect('/login')

    return redirect('/chat')

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message', '').strip()
    if not user_message:
        return jsonify({'error': 'Empty message'}), 400

    if 'chat_history' not in session:
        session['chat_history'] = []

    session['chat_history'].append({
        'type': 'user',
        'message': user_message,
        'timestamp': datetime.now().isoformat()
    })

    try:
        # Check if user is responding to a forum confirmation
        last_assistant_message = None
        if session['chat_history']:
            for msg in reversed(session['chat_history']):
                if msg.get('type') == 'assistant' and msg.get('data'):
                    last_assistant_message = msg
                    break

        # If last message was asking for forum confirmation, handle the yes/no response
        if (last_assistant_message and
            last_assistant_message.get('data', {}).get('awaiting_confirmation') and
            last_assistant_message.get('data', {}).get('action') == 'ask_forum_confirmation'):
            response = handle_forum_confirmation(user_message)
            intent = 'forum_confirmation'
        else:
            # Normal intent detection and handling
            intent = detect_intent(user_message)
            if intent == 'post_analysis':
                response = handle_post_analysis(user_message)
            elif intent == 'job_search':
                response = handle_job_search(user_message)
            elif intent == 'referal_request':
                response = handle_referal_request(user_message)
            elif intent == 'discussion_forum':
                response = handle_discussion_forum(user_message)
            elif intent == 'content_creation':
                response = handle_content_creation(user_message)
            else:
                response = handle_general_query(user_message)

        session['chat_history'].append({
            'type': 'assistant',
            'message': response['message'],
            'data': response.get('data'),
            'timestamp': datetime.now().isoformat()
        })
        return jsonify({
            'success': True,
            'response': response,
            'intent': intent
        })
    except Exception as e:
        error_response = {
            'message': f"I apologize, but I encountered an error: {str(e)}\n\nPlease try again or rephrase your request.",
            'error': True
        }
        session['chat_history'].append({
            'type': 'assistant',
            'message': error_response['message'],
            'error': True,
            'timestamp': datetime.now().isoformat()
        })
        return jsonify({
            'success': False,
            'response': error_response,
            'error': str(e)
        })


def extract_companies_from_message(message):
    # Make extraction case-insensitive and trim whitespace
    pattern = r"(?:at|in|for)\s+([a-zA-Z0-9& ]+)"
    matches = re.findall(pattern, message, re.IGNORECASE)
    return [m.strip().title() for m in matches]

def calculate_experience_years(experience_list):
    total_years = 0
    now = datetime.now()
    for exp in experience_list:
        start_date = exp.get('start_date')
        end_date = exp.get('end_date')
        if start_date:
            if isinstance(start_date, str):
                try:
                    start_date = datetime.fromisoformat(start_date)
                except Exception:
                    continue
        else:
            continue
        if end_date:
            if isinstance(end_date, str):
                try:
                    end_date = datetime.fromisoformat(end_date)
                except Exception:
                    end_date = now
        else:
            end_date = now
        diff = (end_date - start_date).days / 365.25
        if diff > 0:
            total_years += diff
    return round(total_years, 1)

def handle_content_creation(usermessage):
    """Handle content creation requests by auto-redirecting the user"""
    return {
        'message': (
            "📝 **Redirecting to Content Creation Tool**\n\n"
            "You are being redirected to our dedicated content creator interface."
        ),
        'data': {
            'type': 'content_creation',
            'redirect_url': 'http://localhost:8501',
            'action': 'auto_redirect',
            'auto_redirect': True  # Add this flag
        },
        'auto_redirect': True  # Add this at the response level too
    }

def handle_referal_request(usermessage):
    # Step 1: Extract companies from the user message
    companies = extract_companies_from_message(usermessage)
    if not companies:
        return {'message': 'Could not identify any companies in your request. Please specify the companies you want referrals for.'}

    # Step 2: Fetch all user profiles from backend API
    api_url = "http://127.0.0.1:8080/api/users"
    try:
        response = requests.get(api_url)
        if response.status_code != 200:
            return {'message': 'Failed to retrieve user profiles from backend.'}
        profiles = response.json()
    except Exception as e:
        return {'message': f'Error connecting to backend API: {str(e)}'}

    # Debug: Show what companies we're looking for
    print(f"🔍 Looking for referrals to companies: {companies}")

    # Step 3: Filter profiles currently working at the requested companies
    filtered_profiles = []
    for profile in profiles:
        experience = profile.get('experience', [])
        for exp in experience:
            current_company = exp.get('current_company')
            title = exp.get('title', '')

            # Skip if current_company is None or empty
            if not current_company:
                continue

            # Check if any requested company name matches the current company
            if any(company.lower() in current_company.lower() for company in companies):
                exp_years = calculate_experience_years([exp])
                filtered_profiles.append({
                    'profile': profile,
                    'experience_years': exp_years,
                    'title': title,
                    'current_company': current_company
                })
                print(f"✅ Found match: {profile.get('name')} works at {current_company}")
                break

    print(f"📊 Found {len(filtered_profiles)} matching profiles")

    if not filtered_profiles:
        # Show available companies for debugging
        available_companies = set()
        for profile in profiles:
            for exp in profile.get('experience', []):
                company = exp.get('current_company')
                if company:
                    available_companies.add(company)

        available_list = list(available_companies)[:10]  # Show first 10
        return {
            'message': f'No user profiles found working at: {", ".join(companies)}.\n\nAvailable companies include: {", ".join(available_list)}{"..." if len(available_companies) > 10 else ""}'
        }

    # Step 4: Use LLM to rank top 3 profiles by experience, then title
    try:
        llm_client = FreeLLMClient()
        prompt_profiles = []
        for idx, item in enumerate(filtered_profiles, 1):
            p = item['profile']
            name = p.get('name', 'Unknown')
            title = item['title']
            exp_years = item['experience_years']
            prompt_profiles.append(
                f"Profile_{idx}: Name: {name}, Title: {title}, Company: {item['current_company']}, Experience: {exp_years} years"
            )

        system_prompt = (
            "You are an expert career advisor. Given a list of user profiles with their name, title, company, and years of experience, "
            "and a user request for referrals to specific companies, select the top 3 best candidates for referral. "
            "First, prioritize by highest years of experience at the company, then by most relevant title. "
            "Respond with the top 3 profile names and a brief explanation for your ranking."
        )

        user_prompt = (
                f"User request: {usermessage}\n"
                f"Companies: {', '.join(companies)}\n"
                f"Candidate profiles:\n" + "\n".join(prompt_profiles)
        )

        llm_response = llm_client.generate_content(system_prompt, user_prompt, max_tokens=500)

        # Attempt to extract top 3 names from the LLM response
        top_3_names = []
        lines = llm_response.split('\n')
        for line in lines:
            for item in filtered_profiles:
                if item['profile'].get('name', '') in line:
                    top_3_names.append(item['profile'].get('name', 'Unknown'))
                    if len(top_3_names) >= 3:
                        break
            if len(top_3_names) >= 3:
                break

        top_3_profiles = [item['profile'] for item in filtered_profiles if item['profile'].get('name', '') in top_3_names]

        return {
            'message': f'Top 3 referral candidates for companies {", ".join(companies)}:\n\n{llm_response}',
            'data': {
                'top_candidates': top_3_profiles,
                'llm_reasoning': llm_response
            }
        }
    except Exception as e:
        # Fallback: return all matching profiles if LLM fails
        return {
            'message': f'Found {len(filtered_profiles)} referral candidates for {", ".join(companies)} (LLM ranking unavailable):',
            'data': {
                'top_candidates': [item['profile'] for item in filtered_profiles[:3]],
                'llm_reasoning': f'LLM error: {str(e)}'
            }
        }

def handle_post_analysis(user_question):
    user_profile = get_user_profile()
    user_id = user_profile.get('id') or user_profile.get('_id')

    # Fetch all posts for this user from the FastAPI API
    api_url = f"http://127.0.0.1:8080/api/users/{user_id}/posts"
    response = requests.get(api_url)
    if response.status_code != 200:
        return {'message': 'Failed to retrieve posts for analysis.'}

    posts = response.json()
    post_contents = [post.get('post_content', '') for post in posts]

    # Format posts for the prompt
    formatted_posts = ""
    for idx, content in enumerate(post_contents, 1):
        formatted_posts += f"post_{idx}: {content}\n"

    # Prepare prompts for the LLM
    system_prompt = (
        "You are a professional LinkedIn content analyst. "
        "Given multiple user posts (each labeled as post_1, post_2, etc.) and a user question, "
        "provide a detailed, insightful, and actionable analysis based strictly on the provided posts."
    )
    user_prompt = (
        f"Here are the user's posts:\n{formatted_posts}\n"
        f"User question: {user_question}\n\n"
        "Please provide your analysis."
    )

    # Generate analysis using LLM
    llm_client = FreeLLMClient()
    analysis = llm_client.generate_content(system_prompt, user_prompt, max_tokens=500)

    return {
        'message': 'Post analysis complete.' + analysis
    }

from free_llm_client import FreeLLMClient
import requests

def handle_job_search(message):
    # Step 1: Get user profile from session and backend API for latest skills
    user_profile = get_user_profile()
    user_id = user_profile.get('id') or user_profile.get('_id')
    api_url = f"http://127.0.0.1:8080/api/users/{user_id}"
    response = requests.get(api_url)
    if response.status_code != 200:
        return {'message': 'Failed to retrieve user profile for skills analysis.'}

    profile_data = response.json()
    user_skills = profile_data.get('skills', [])

    # Step 2: Extract job query and fetch jobs using LinkedIn assistant
    job_query = extract_job_query(message)
    linkedin_assistant = get_assistant_with_session()
    if not linkedin_assistant:
        return {
            'message': "❌ LinkedIn Assistant is not available. Please check the server logs for initialization errors."
        }
    result = linkedin_assistant.find_jobs_and_match(user_profile, job_query)
    if not result.get('success') or not result.get('jobs'):
        return {
            'message': f"🔍 I searched for '{job_query}' but couldn't find any matching opportunities right now.\n\nTry:\n• Different keywords\n• Broader location criteria\n• Related job titles\n\nWhat else would you like me to search for?"
        }
    jobs = result['jobs']

    # Step 3: Prepare LLM prompt for analysis
    system_prompt = (
        "You are a career advisor AI. Given a user's skills and a list of job descriptions, "
        "analyze and suggest the best job matches for the user. Provide reasoning for each suggestion."
    )
    skills_text = ", ".join(user_skills) if user_skills else "No skills provided"
    job_texts = []
    for idx, job in enumerate(jobs, 1):
        job_desc = (
            f"Job_{idx}: Title: {job.get('title', 'N/A')}, "
            f"Company: {job.get('company', 'N/A')}, "
            f"Location: {job.get('location', 'N/A')}, "
            f"Requirements: {job.get('requirements', 'N/A') if 'requirements' in job else 'N/A'}"
        )
        job_texts.append(job_desc)
    jobs_text = "\n".join(job_texts)
    user_prompt = (
        f"User skills: {skills_text}\n\n"
        f"Jobs:\n{jobs_text}\n\n"
        "Please analyze and suggest the best job matches for the user with explanations."
    )

    # Step 4: Use LLM for analysis
    llm_client = FreeLLMClient()
    analysis = llm_client.generate_content(system_prompt, user_prompt, max_tokens=500)

    # Step 5: Build response
    response_message = f"🔍 Found {len(jobs)} job opportunities for you based on your query '{job_query}'.\n\n"
    response_message += "Here are the top matches with analysis:\n\n"
    response_message += analysis

    return {
        'message': response_message,
        'data': {
            'type': 'jobs',
            'jobs': jobs,
            'query': job_query,
            'user_skills': user_skills,
            'llm_analysis': analysis
        }
    }

def handle_general_query(message):
    """Handle general queries and provide guidance"""
    return {
        'message': f"I'd be happy to help! I specialize in several key areas:\n\n📝 **Content Creation**\n• *'Write a post about my promotion to Senior ML Engineer'*\n• *'Create content about launching my AI project that improved efficiency by 40%'*\n• *'Share insights from the AI conference I attended in Mumbai'*\n\n🔍 **Job Search & Career**\n• *'Find me ML engineer jobs in Bangalore India'*\n• *'Search for AI researcher roles at top tech companies'*\n• *'Look for remote data science positions at startups'*\n\n💡 **Industry Insights**\n• *'Create a post about the latest trends in generative AI'*\n• *'Share best practices for deploying ML models in production'*\n• *'Write about the future of LLMs in Indian languages'*\n\n🚀 **Career Development**\n• *'Help me write about transitioning from SWE to ML engineering'*\n• *'Create content about mentoring junior developers'*\n• *'Share my experience building an AI team from scratch'*\n\nWhat would you like assistance with today?"
    }
# Chrome Extension API Endpoints

@app.route('/api/connect', methods=['POST'])
def connect_linkedin():
    """Connect to LinkedIn with provided credentials"""
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        if not email or not password:
            return jsonify({'success': False, 'error': 'Email and password required'})

        # Update assistant with new credentials
        global assistant
        assistant = LinkedInAssistant(email=email, password=password)

        # Get user profile to verify connection
        profile = assistant.get_user_profile()

        if profile.get('success'):
            return jsonify({
                'success': True,
                'profile': profile.get('profile'),
                'message': 'Connected successfully'
            })
        else:
            return jsonify({'success': False, 'error': 'Failed to connect to LinkedIn'})

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/profile', methods=['GET'])
def get_profile():
    """Get current user's LinkedIn profile"""
    try:
        linkedin_assistant = get_assistant_with_session()
        profile = linkedin_assistant.get_user_profile()
        return jsonify(profile)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/jobs', methods=['POST'])
def search_jobs_api():
    """Enhanced job search API for Chrome extension"""
    try:
        data = request.get_json()
        query = data.get('query', '')

        if not query:
            return jsonify({'success': False, 'error': 'Query is required'})

        linkedin_assistant = get_assistant_with_session()

        # Use session profile or user-provided profile if available
        profile = data.get('profile', get_user_profile())

        result = linkedin_assistant.find_jobs_and_match(profile, query)

        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/analyze-trends', methods=['POST'])
def analyze_trends():
    """Analyze trending LinkedIn posts for a given topic"""
    try:
        data = request.get_json()
        topic = data.get('topic', '')

        if not topic:
            return jsonify({'success': False, 'error': 'Topic is required'})

        linkedin_assistant = get_assistant_with_session()
        trends = linkedin_assistant.analyze_trending_posts(topic)

        return jsonify({'success': True, 'trends': trends})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/optimize-post', methods=['POST'])
def optimize_post():
    """Optimize post content based on trends and user preferences"""
    try:
        data = request.get_json()
        content = data.get('content', {})
        trends = data.get('trends', [])

        linkedin_assistant = get_assistant_with_session()
        optimized_post = linkedin_assistant.optimize_post_content(content, trends)

        return jsonify({'success': True, 'post': optimized_post})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/post', methods=['POST'])
def create_post():
    """Create and optionally publish a LinkedIn post"""
    try:
        data = request.get_json()
        content = data.get('content', '')
        publish = data.get('publish', False)

        if not content:
            return jsonify({'success': False, 'error': 'Content is required'})

        linkedin_assistant = get_assistant_with_session()

        if publish:
            result = linkedin_assistant.create_post(content)
        else:
            # Just return the content for review
            result = {
                'success': True,
                'content': content,
                'posted': False,
                'message': 'Post created successfully (not published)'
            }

        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/analyze-profile', methods=['POST'])
def analyze_profile():
    """Analyze LinkedIn profile and provide insights"""
    try:
        data = request.get_json()
        profile_data = data.get('profileData', {})

        linkedin_assistant = get_assistant_with_session()
        insights = linkedin_assistant.analyze_profile_insights(profile_data)

        return jsonify({'success': True, 'insights': insights})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/history')
def get_history():
    """Get chat history"""
    if 'chat_history' not in session:
        session['chat_history'] = []
    return jsonify({
        'history': session['chat_history'],
        'session_id': session.get('session_id')
    })

@app.route('/api/clear')
def clear_history():
    """Clear chat history"""
    session['chat_history'] = []
    initialize_session()
    return jsonify({'success': True})

def handle_forum_confirmation(user_message):
    """
    Handle yes/no response for forum redirection confirmation
    """
    message_lower = user_message.lower().strip()

    # Check for positive responses
    if any(word in message_lower for word in ['yes', 'y', 'ok', 'okay', 'sure', 'take me', 'redirect', 'forums']):
        return {
            'message': f"🚀 **Excellent! Redirecting you to LinkedIn Forums AI...**\n\n"
                      f"You'll be taken to our specialized discussion platform where you can:\n\n"
                      f"💬 Connect with professionals\n"
                      f"🤝 Share your insights\n"
                      f"📈 Learn from the community\n\n"
                      f"**Redirecting you now...** 🎉",
            'data': {
                'type': 'forum_redirect',
                'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
                'action': 'auto_redirect',
                'confirmed': True,
                'auto_redirect': True
            }
        }

    # Check for negative responses
    elif any(word in message_lower for word in ['no', 'n', 'nope', 'continue', 'stay', 'here']):
        return {
            'message': f"👍 **No problem! Let's continue our conversation here.**\n\n"
                      f"I'm happy to help you with your question. How can I assist you further?\n\n"
                      f"I can help with:\n"
                      f"📝 **Content Creation** - LinkedIn posts and professional content\n"
                      f"🔍 **Job Search** - Finding opportunities and career advice\n"
                      f"👥 **Referrals** - Connecting you with professionals\n"
                      f"📊 **Post Analysis** - Analyzing your LinkedIn content\n\n"
                      f"What would you like to explore?",
            'data': {
                'type': 'continue_conversation',
                'action': 'declined_redirect',
                'confirmed': False
            }
        }

    # Unclear response - ask again
    else:
        return {
            'message': f"🤔 **I didn't quite catch that.**\n\n"
                      f"Would you like me to redirect you to the LinkedIn Forums AI platform for community discussion?\n\n"
                      f"Please respond with:\n"
                      f"• **Yes** or **Y** - Take me to the forums\n"
                      f"• **No** or **N** - Continue here\n\n"
                      f"💡 *Just type 'yes' or 'no' to let me know!*",
            'data': {
                'type': 'forum_confirmation',
                'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
                'action': 'ask_forum_confirmation',
                'awaiting_confirmation': True
            }
        }

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)