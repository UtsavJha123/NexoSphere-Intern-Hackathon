#!/usr/bin/env python3

import sys
import os

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def extract_discussion_topic(message):
    """Extract the main discussion topic from the user message"""
    
    # Remove common question prefixes to get the core topic
    prefixes_to_remove = [
        'i want to discuss',
        'let\'s discuss',
        'can we discuss',
        'what do you think about',
        'what are your thoughts on',
        'i\'d like feedback on',
        'can i get opinions on',
        'what\'s the community view on',
        'help me understand',
        'looking for advice on',
        'seeking input on'
    ]
    
    message_lower = message.lower().strip()
    
    # Remove common prefixes
    for prefix in prefixes_to_remove:
        if message_lower.startswith(prefix):
            topic = message_lower.replace(prefix, '').strip()
            # Remove leading question words
            topic = topic.lstrip('about on regarding concerning').strip()
            # Capitalize first letter and return
            return topic.capitalize() if topic else message.strip()
    
    # If no prefix found, return the original message but cleaned up
    # Remove question marks and clean up
    cleaned = message.strip().rstrip('?!.')
    return cleaned if cleaned else message.strip()

def handle_discussion_forum(usermessage):
    """
    Handle discussion forum requests by analyzing the user message
    and redirecting to the LinkedIn Forums AI platform
    """
    
    # Keywords that indicate discussion/forum related requests
    forum_keywords = [
        'discuss', 'discussion', 'forum', 'community', 'group', 'debate', 
        'opinion', 'thoughts', 'what do you think', 'feedback', 'advice',
        'share experience', 'ask community', 'peer input', 'networking group',
        'professional discussion', 'industry forum', 'connect with peers'
    ]
    
    # Check if the message contains forum-related keywords
    message_lower = usermessage.lower()
    forum_related = any(keyword in message_lower for keyword in forum_keywords)
    
    if forum_related:
        # Extract the main topic from the user message for context
        topic = extract_discussion_topic(usermessage)
        
        return {
            'message': f"🗣️ **Great question for community discussion!**\n\n"
                      f"Your topic: *\"{topic}\"*\n\n"
                      f"I'm redirecting you to our **LinkedIn Forums AI** platform where you can:\n\n"
                      f"💬 **Engage with professionals** in meaningful discussions\n"
                      f"🧠 **Get diverse perspectives** from industry experts\n"
                      f"🤝 **Build connections** through thoughtful conversations\n"
                      f"📈 **Share insights** and learn from others\n\n"
                      f"**Ready to join the discussion?**\n\n"
                      f"[🚀 **Access LinkedIn Forums AI**](https://linked-in-forums-ai-54.lovable.app)\n\n"
                      f"This specialized platform is designed for professional discussions and will help you get the community input you're looking for!",
            'data': {
                'type': 'forum_redirect',
                'topic': topic,
                'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
                'action': 'redirect_to_forum',
                'original_message': usermessage
            }
        }
    else:
        # If not clearly forum-related, suggest it might be better for forums
        return {
            'message': f"🤔 **This seems like it could benefit from community input!**\n\n"
                      f"Your message: *\"{usermessage}\"*\n\n"
                      f"While I can help with individual tasks, **community discussions** often provide richer insights. Consider taking this to our LinkedIn Forums AI platform where you can:\n\n"
                      f"🌟 **Get multiple perspectives** from professionals\n"
                      f"💡 **Discover new ideas** through community wisdom\n"
                      f"🔗 **Network naturally** through meaningful conversations\n\n"
                      f"**Want to explore the forums?**\n\n"
                      f"[📋 **Check out LinkedIn Forums AI**](https://linked-in-forums-ai-54.lovable.app)\n\n"
                      f"Or feel free to continue our conversation here - I'm happy to help either way!",
            'data': {
                'type': 'forum_suggestion',
                'topic': usermessage,
                'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
                'action': 'suggest_forum',
                'original_message': usermessage
            }
        }

if __name__ == "__main__":
    print("Testing handle_discussion_forum function...")
    print("=" * 60)
    
    # Test cases for forum-related messages
    test_cases = [
        # Clear forum-related messages
        "I want to discuss the future of AI in healthcare",
        "What do you think about remote work policies?",
        "Can we discuss the latest trends in machine learning?",
        "Looking for community feedback on my startup idea",
        "What are your thoughts on the new LinkedIn features?",
        
        # Edge cases
        "Let's debate whether AI will replace developers",
        "Seeking advice on career transitions",
        "I'd like to share my experience with cryptocurrency trading",
        
        # Non-forum messages (should suggest forum)
        "Create a post about my promotion",
        "Find me jobs in tech",
        "How do I optimize my LinkedIn profile?"
    ]
    
    for i, test_message in enumerate(test_cases, 1):
        print(f"\nTest {i}: \"{test_message}\"")
        print("-" * 50)
        
        result = handle_discussion_forum(test_message)
        
        print(f"Action type: {result['data']['action']}")
        print(f"Topic extracted: \"{result['data']['topic']}\"")
        print(f"Message preview: {result['message'][:100]}...")
        
        # Check if redirect URL is included
        if 'https://linked-in-forums-ai-54.lovable.app' in result['message']:
            print("✅ Forum URL correctly included")
        else:
            print("❌ Forum URL missing")
            
    print(f"\n" + "=" * 60)
    print("Testing complete!")
