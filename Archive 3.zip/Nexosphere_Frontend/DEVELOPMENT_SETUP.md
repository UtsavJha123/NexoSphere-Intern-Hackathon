# Development Environment Setup

## Overview
This document explains how to set up the development environment for the Nexosphere project after cloning the repository.

## Why Virtual Environments Were Removed
Virtual environments (venv directories) have been removed from the repository because they:
- Take up significant disk space (600+ MB)
- Contain platform-specific binaries
- Can be easily recreated from requirements.txt
- Should not be shared between developers

## Setting Up Your Development Environment

### For Nexosphere_Frontend (Main Project)
```bash
cd Nexosphere_Frontend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### For Nexosphere (Backend)
```bash
cd ../Nexosphere
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### For post-creation 3 (LinkedIn Post Generator)
```bash
cd "../post-creation 3"
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Environment Variables
Each project may have environment variables that need to be configured:
- Copy `.env.example` to `.env` in each project directory
- Fill in the required API keys and configuration values

## .gitignore Protection
The updated `.gitignore` file now includes comprehensive patterns to prevent virtual environments from being accidentally committed:
- `venv/`, `.venv/`, `.venv2/`, `.venv3/`
- Wildcard patterns: `**/venv/`, `**/.venv*/`
- Environment files: `.env` (while preserving `.env.example`)

## Benefits of This Approach
1. **Smaller Repository**: Reduced from 750MB to ~8MB (99% reduction)
2. **Faster Cloning**: Much quicker to download and clone
3. **Platform Independence**: Each developer creates their own environment
4. **Cleaner Repository**: Only source code and configuration files are tracked
5. **Better Collaboration**: No conflicts from different Python installations

## Notes
- Always activate your virtual environment before working on the project
- If you encounter dependency issues, try recreating the virtual environment
- Keep requirements.txt files updated when adding new dependencies
