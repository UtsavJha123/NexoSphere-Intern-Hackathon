#!/usr/bin/env python3

def detect_intent_fallback(message):
    """
    Fallback intent detection using keywords when LLM is unavailable.
    """
    message_lower = message.lower()
    if any(keyword in message_lower for keyword in ['analyze', 'analysis', 'performance', 'metrics', 'engagement', 'views', 'likes', 'comments', 'trending', 'viral']):
        return 'post_analysis'
    elif any(keyword in message_lower for keyword in ['referral', 'refer', 'recommendation', 'connect me', 'introduce', 'know someone', 'contact at']):
        return 'referal_request'
    elif any(keyword in message_lower for keyword in ['discuss', 'question', 'thoughts', 'opinion', 'what do you think', 'community', 'forum', 'debate']):
        return 'discussion_forum'
    elif any(keyword in message_lower for keyword in ['job', 'career', 'position', 'role', 'opportunity', 'hire', 'work', 'employment', 'search']):
        return 'job_search'
    else:
        return 'general_query'

def handle_discussion_forum(usermessage):
    """
    Handle discussion forum requests by redirecting to the LinkedIn Forums AI platform.
    Since detect_intent already identified this as forum-related, we directly redirect.
    """
    
    return {
        'message': f"🗣️ **Perfect! This is a great topic for community discussion.**\n\n"
                  f"I'm redirecting you to our **LinkedIn Forums AI** platform where you can:\n\n"
                  f"💬 **Engage with professionals** in meaningful discussions\n"
                  f"🧠 **Get diverse perspectives** from industry experts\n"
                  f"🤝 **Build connections** through thoughtful conversations\n"
                  f"📈 **Share insights** and learn from the community\n\n"
                  f"**Ready to join the discussion?**\n\n"
                  f"[🚀 **Access LinkedIn Forums AI**](https://linked-in-forums-ai-54.lovable.app)\n\n"
                  f"This specialized platform is designed for professional discussions and will help you get the community input you're looking for!",
        'data': {
            'type': 'forum_redirect',
            'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
            'action': 'redirect_to_forum',
            'original_message': usermessage
        }
    }

def test_complete_flow():
    """Test the complete flow from intent detection to forum handling"""
    
    # Test messages that should be detected as discussion_forum intent
    test_messages = [
        'What do you think about remote work?',
        'I want to discuss AI trends',
        'Can I get community feedback on this?',
        'Looking for opinions on career change',
        'What are your thoughts on LinkedIn strategy?',
        'Help me get advice from the community'
    ]

    print('Testing intent detection and forum handling...')
    print('=' * 60)

    for message in test_messages:
        intent = detect_intent_fallback(message)
        print(f'Message: "{message}"')
        print(f'Detected intent: {intent}')
        
        if intent == 'discussion_forum':
            result = handle_discussion_forum(message)
            print(f'✅ Redirected to: {result["data"]["redirect_url"]}')
            print(f'Action: {result["data"]["action"]}')
        else:
            print(f'❌ Not detected as forum intent')
        print('-' * 40)

if __name__ == "__main__":
    test_complete_flow()
