#!/usr/bin/env python3
"""
Test script for handle_referal_request function
"""

import os
import re
import sys
import requests
from datetime import datetime

# Add the project directory to path
sys.path.append('/Users/akumar17/project/rsc/Nexosphere_Frontend')

def extract_companies_from_message(message):
    # Make extraction case-insensitive and trim whitespace
    pattern = r"(?:at|in|for)\s+([a-zA-Z0-9& ]+)"
    matches = re.findall(pattern, message, re.IGNORECASE)
    return [m.strip().title() for m in matches]

def calculate_experience_years(experience_list):
    total_years = 0
    now = datetime.now()
    for exp in experience_list:
        start_date = exp.get('start_date')
        end_date = exp.get('end_date')
        if start_date:
            if isinstance(start_date, str):
                try:
                    start_date = datetime.fromisoformat(start_date)
                except Exception:
                    continue
        else:
            continue
        if end_date:
            if isinstance(end_date, str):
                try:
                    end_date = datetime.fromisoformat(end_date)
                except Exception:
                    end_date = now
        else:
            end_date = now
        diff = (end_date - start_date).days / 365.25
        if diff > 0:
            total_years += diff
    return round(total_years, 1)

def handle_referal_request(usermessage):
    # Step 1: Extract companies from the user message
    companies = extract_companies_from_message(usermessage)
    if not companies:
        return {'message': 'Could not identify any companies in your request. Please specify the companies you want referrals for.'}

    # Step 2: Fetch all user profiles from backend API
    api_url = "http://127.0.0.1:8080/api/users"
    try:
        response = requests.get(api_url)
        if response.status_code != 200:
            return {'message': 'Failed to retrieve user profiles from backend.'}
        profiles = response.json()
    except Exception as e:
        return {'message': f'Error connecting to backend API: {str(e)}'}

    # Debug: Show what companies we're looking for
    print(f"🔍 Looking for referrals to companies: {companies}")

    # Step 3: Filter profiles currently working at the requested companies
    filtered_profiles = []
    for profile in profiles:
        experience = profile.get('experience', [])
        for exp in experience:
            current_company = exp.get('current_company')
            title = exp.get('title', '')
            
            # Skip if current_company is None or empty
            if not current_company:
                continue
                
            # Check if any requested company name matches the current company
            if any(company.lower() in current_company.lower() for company in companies):
                exp_years = calculate_experience_years([exp])
                filtered_profiles.append({
                    'profile': profile,
                    'experience_years': exp_years,
                    'title': title,
                    'current_company': current_company
                })
                print(f"✅ Found match: {profile.get('name')} works at {current_company}")
                break

    print(f"📊 Found {len(filtered_profiles)} matching profiles")

    if not filtered_profiles:
        # Show available companies for debugging
        available_companies = set()
        for profile in profiles:
            for exp in profile.get('experience', []):
                company = exp.get('current_company')
                if company:
                    available_companies.add(company)
        
        available_list = list(available_companies)[:10]  # Show first 10
        return {
            'message': f'No user profiles found working at: {", ".join(companies)}.\n\nAvailable companies include: {", ".join(available_list)}{"..." if len(available_companies) > 10 else ""}'
        }

    # For testing, just return the first 3 matches
    return {
        'message': f'Found {len(filtered_profiles)} referral candidates for {", ".join(companies)}:',
        'data': {
            'top_candidates': [item['profile'] for item in filtered_profiles[:3]],
            'llm_reasoning': 'LLM disabled for testing'
        }
    }

if __name__ == "__main__":
    print("Testing handle_referal_request function...")
    print("="*50)
    
    # Test 1: With an existing company
    print("Test 1 - Barnes LLC:")
    result = handle_referal_request('I want referral for Barnes LLC')
    print(result['message'])
    print()
    
    # Test 2: With Google (should show available companies)
    print("Test 2 - Google:")
    result = handle_referal_request('I want referral for google')
    print(result['message'])
    print()
    
    # Test 3: With Hogan Group
    print("Test 3 - Hogan Group:")
    result = handle_referal_request('I want referral for Hogan Group')
    print(result['message'])
