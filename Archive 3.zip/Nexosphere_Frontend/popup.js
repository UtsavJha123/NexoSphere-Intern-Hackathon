// Chrome Extension Popup JavaScript
class LinkedInAssistantPopup {
    constructor() {
        this.init();
    }

    async init() {
        await this.loadStoredCredentials();
        this.bindEvents();
        await this.checkConnection();
    }

    async loadStoredCredentials() {
        const result = await chrome.storage.local.get(['linkedinCredentials', 'userProfile']);
        if (result.linkedinCredentials) {
            document.getElementById('linkedinEmail').value = result.linkedinCredentials.email || '';
        }
        
        if (result.userProfile) {
            this.showProfileSection(result.userProfile);
        }
    }

    bindEvents() {
        document.getElementById('connectBtn').addEventListener('click', () => this.connectToLinkedIn());
        document.getElementById('openAssistantBtn').addEventListener('click', () => this.openFullAssistant());
        document.getElementById('disconnectBtn').addEventListener('click', () => this.disconnect());
        
        // Feature buttons
        document.getElementById('createPostBtn').addEventListener('click', () => this.openFeature('create-post'));
        document.getElementById('searchJobsBtn').addEventListener('click', () => this.openFeature('search-jobs'));
        document.getElementById('analyzePostsBtn').addEventListener('click', () => this.openFeature('analyze-posts'));
        document.getElementById('profileInsightsBtn').addEventListener('click', () => this.openFeature('profile-insights'));
    }

    async connectToLinkedIn() {
        const email = document.getElementById('linkedinEmail').value.trim();
        const password = document.getElementById('linkedinPassword').value.trim();

        if (!email || !password) {
            this.showStatus('Please enter both email and password', 'error');
            return;
        }

        this.showStatus('Connecting to LinkedIn...', 'info');

        try {
            // Store credentials securely
            await chrome.storage.local.set({
                linkedinCredentials: { email, password }
            });

            // Test connection via background script
            const response = await chrome.runtime.sendMessage({
                action: 'connectLinkedIn',
                credentials: { email, password }
            });

            if (response.success) {
                this.showStatus('Connected successfully!', 'success');
                await this.fetchUserProfile();
            } else {
                throw new Error(response.error || 'Connection failed');
            }
        } catch (error) {
            this.showStatus(`Connection failed: ${error.message}`, 'error');
        }
    }

    async fetchUserProfile() {
        try {
            const response = await chrome.runtime.sendMessage({
                action: 'getUserProfile'
            });

            if (response.success) {
                const profile = response.profile;
                await chrome.storage.local.set({ userProfile: profile });
                this.showProfileSection(profile);
            } else {
                throw new Error(response.error || 'Failed to fetch profile');
            }
        } catch (error) {
            this.showStatus(`Failed to fetch profile: ${error.message}`, 'error');
        }
    }

    showProfileSection(profile) {
        document.getElementById('authSection').classList.add('hidden');
        document.getElementById('profileSection').classList.remove('hidden');

        document.getElementById('profileName').textContent = profile.name || 'Unknown User';
        document.getElementById('profileTitle').textContent = profile.headline || 'No title';
        
        if (profile.profilePicture) {
            document.getElementById('profileAvatar').src = profile.profilePicture;
        }
    }

    async openFeature(feature) {
        // Inject content script and open assistant with specific feature
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        // For content creation features, first extract real profile data
        if (feature === 'create-post' || feature === 'analyze-posts') {
            // Check if we're on a LinkedIn profile page
            if (tab.url.includes('linkedin.com/in/')) {
                try {
                    // Extract real profile data first
                    const profileResponse = await chrome.tabs.sendMessage(tab.id, {
                        action: 'extractProfileData'
                    });
                    
                    if (profileResponse && profileResponse.profileData) {
                        // Store the real profile data
                        await chrome.storage.local.set({ 'realProfileData': profileResponse.profileData });
                        
                        // If analyzing posts, also extract post data
                        if (feature === 'analyze-posts') {
                            // Navigate to LinkedIn feed first to analyze trending posts
                            await chrome.tabs.update(tab.id, { url: 'https://www.linkedin.com/feed/' });
                            
                            // Wait for page to load
                            setTimeout(async () => {
                                const postResponse = await chrome.tabs.sendMessage(tab.id, {
                                    action: 'extractPostData'
                                });
                                
                                if (postResponse && postResponse.postData) {
                                    await chrome.storage.local.set({ 'trendingPostData': postResponse.postData });
                                }
                                
                                // Now open the assistant with extracted data
                                await chrome.tabs.sendMessage(tab.id, {
                                    action: 'openAssistant',
                                    feature: feature,
                                    realProfile: true
                                });
                            }, 3000);
                            return;
                        }
                    }
                } catch (err) {
                    console.error('Error extracting profile data:', err);
                }
            }
        }
        
        if (tab.url.includes('linkedin.com')) {
            await chrome.tabs.sendMessage(tab.id, {
                action: 'openAssistant',
                feature: feature
            });
            window.close();
        } else {
            // Open LinkedIn and then the assistant
            await chrome.tabs.create({
                url: 'https://www.linkedin.com/feed/',
                active: true
            });
            
            // Wait a bit for LinkedIn to load, then inject assistant
            setTimeout(async () => {
                const [newTab] = await chrome.tabs.query({ active: true, currentWindow: true });
                await chrome.tabs.sendMessage(newTab.id, {
                    action: 'openAssistant',
                    feature: feature
                });
                window.close();
            }, 3000);
        }
    }

    async openFullAssistant() {
        await this.openFeature('full-assistant');
    }

    async disconnect() {
        await chrome.storage.local.clear();
        await chrome.runtime.sendMessage({ action: 'disconnect' });
        
        document.getElementById('authSection').classList.remove('hidden');
        document.getElementById('profileSection').classList.add('hidden');
        document.getElementById('linkedinPassword').value = '';
        
        this.showStatus('Disconnected successfully', 'info');
    }

    async checkConnection() {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'checkConnection' });
            if (response.connected) {
                const profile = await chrome.storage.local.get(['userProfile']);
                if (profile.userProfile) {
                    this.showProfileSection(profile.userProfile);
                }
            }
        } catch (error) {
            console.log('No connection available');
        }
    }

    showStatus(message, type) {
        const statusEl = document.getElementById('statusMessage');
        statusEl.textContent = message;
        statusEl.className = `status ${type}`;
        statusEl.classList.remove('hidden');

        setTimeout(() => {
            statusEl.classList.add('hidden');
        }, 3000);
    }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LinkedInAssistantPopup();
});
