// Content script for LinkedIn pages
class LinkedInAssistantContent {
    constructor() {
        this.assistantContainer = null;
        this.isInjected = false;
        this.init();
    }

    init() {
        // Listen for messages from popup and background
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true;
        });

        // Auto-inject assistant button on LinkedIn pages
        if (window.location.hostname === 'www.linkedin.com') {
            this.injectAssistantButton();
        }
    }

    handleMessage(message, sender, sendResponse) {
        switch (message.action) {
            case 'openAssistant':
                this.openAssistant(message.feature, {
                    realProfile: message.realProfile || false
                });
                sendResponse({ success: true });
                break;
                
            case 'extractProfileData':
                const profileData = this.extractCurrentProfileData();
                sendResponse({ success: true, profileData: profileData });
                sendResponse({ success: true, data: profileData });
                break;
                
            case 'extractPostData':
                const postData = this.extractPostData();
                sendResponse({ success: true, data: postData });
                break;
                
            default:
                sendResponse({ success: false, error: 'Unknown action' });
        }
    }

    injectAssistantButton() {
        // Inject a floating AI assistant button
        const button = document.createElement('div');
        button.id = 'linkedin-ai-assistant-btn';
        button.innerHTML = '🤖';
        button.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #0077b5, #00a0dc);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            z-index: 10000;
            font-size: 24px;
            box-shadow: 0 4px 12px rgba(0, 119, 181, 0.3);
            transition: all 0.3s ease;
        `;

        button.onmouseenter = () => {
            button.style.transform = 'scale(1.1)';
            button.style.boxShadow = '0 6px 16px rgba(0, 119, 181, 0.4)';
        };

        button.onmouseleave = () => {
            button.style.transform = 'scale(1)';
            button.style.boxShadow = '0 4px 12px rgba(0, 119, 181, 0.3)';
        };

        button.onclick = () => this.openAssistant('full-assistant');

        document.body.appendChild(button);
    }

    openAssistant(feature = 'full-assistant', options = {}) {
        if (this.isInjected) {
            this.assistantContainer.style.display = 'block';
            return;
        }

        // Check if we should use real profile data
        const useRealProfile = options.realProfile || false;
        
        this.createAssistantInterface(feature, useRealProfile);
        
        // If this is an analyze or create post feature with real profile,
        // let's prepare additional data
        if (useRealProfile && (feature === 'analyze-posts' || feature === 'create-post')) {
            // Get profile data from storage
            chrome.storage.local.get(['realProfileData', 'trendingPostData'], (result) => {
                if (result.realProfileData) {
                    // Send profile data to the assistant iframe
                    const iframe = document.querySelector('#linkedin-ai-assistant-container iframe');
                    if (iframe && iframe.contentWindow) {
                        iframe.addEventListener('load', () => {
                            iframe.contentWindow.postMessage({
                                type: 'setRealProfileData',
                                profileData: result.realProfileData,
                                trendingPosts: result.trendingPostData || []
                            }, '*');
                        });
                    }
                }
            });
        }
    }

    createAssistantInterface(feature) {
        const container = document.createElement('div');
        container.id = 'linkedin-ai-assistant-container';
        container.style.cssText = `
            position: fixed;
            top: 0;
            right: 0;
            width: 400px;
            height: 100vh;
            background: white;
            border-left: 1px solid #e0e0e0;
            z-index: 10001;
            box-shadow: -4px 0 12px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;

        const iframe = document.createElement('iframe');
        iframe.style.cssText = `
            width: 100%;
            height: 100%;
            border: none;
        `;
        
        // Create assistant HTML content
        iframe.srcdoc = this.createAssistantHTML(feature);
        container.appendChild(iframe);

        // Add close button
        const closeBtn = document.createElement('div');
        closeBtn.innerHTML = '×';
        closeBtn.style.cssText = `
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
            z-index: 10002;
        `;
        closeBtn.onclick = () => this.closeAssistant();
        container.appendChild(closeBtn);

        document.body.appendChild(container);
        this.assistantContainer = container;
        this.isInjected = true;
    }

    createAssistantHTML(feature, realProfile = false) {
        return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f8f9fa;
            height: 100vh;
            overflow-y: auto;
        }
        
        .header {
            background: linear-gradient(135deg, #0077b5, #00a0dc);
            color: white;
            padding: 20px;
            margin: -20px -20px 20px -20px;
            text-align: center;
            position: relative;
        }
        
        .header h1 {
            margin: 0;
            font-size: 20px;
        }
        
        .real-profile-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #2e7d32;
            color: white;
            font-size: 12px;
            padding: 3px 8px;
            border-radius: 12px;
        }
        
        .feature-section {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .feature-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #0077b5;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }
        
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            box-sizing: border-box;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .btn {
            background: #0077b5;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.3s ease;
        }
        
        .btn:hover {
            background: #005885;
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .result-section {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 15px;
            margin-top: 15px;
        }
        
        .trend-item {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 10px;
            margin-bottom: 10px;
        }
        
        .hashtag {
            display: inline-block;
            background: #e3f2fd;
            color: #1976d2;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            margin: 2px;
        }
        
        .job-item {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 15px;
        }
        
        .job-title {
            font-weight: 600;
            color: #0077b5;
            margin-bottom: 5px;
        }
        
        .job-company {
            color: #666;
            font-size: 14px;
        }
        
        .hidden {
            display: none;
        }
        
        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }
        
        .quick-use-case {
            background: #e3f2fd;
            color: #1976d2;
            border: 1px solid #bbdefb;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .quick-use-case:hover {
            background: #1976d2;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚀 LinkedIn AI Assistant</h1>
    </div>

    <!-- Post Creation Feature -->
    <div id="createPostSection" class="feature-section">
        <div class="feature-title">✨ Create Engaging Post</div>
        
        <!-- Quick Use Case Buttons -->
        <div style="margin-bottom: 15px;">
            <div style="font-weight: 500; margin-bottom: 8px; color: #333;">🚀 Quick Use Cases:</div>
            <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                <button class="quick-use-case" onclick="fillPostExample('promotion')">📈 Promotion</button>
                <button class="quick-use-case" onclick="fillPostExample('project')">🚀 Project Launch</button>
                <button class="quick-use-case" onclick="fillPostExample('certification')">🏆 Certification</button>
                <button class="quick-use-case" onclick="fillPostExample('conference')">🎤 Conference</button>
                <button class="quick-use-case" onclick="fillPostExample('research')">🔬 Research</button>
                <button class="quick-use-case" onclick="fillPostExample('startup')">💡 Startup</button>
                <button class="quick-use-case" onclick="fillPostExample('mentoring')">👥 Mentoring</button>
                <button class="quick-use-case" onclick="fillPostExample('insights')">💭 Insights</button>
            </div>
        </div>
        
        <div class="form-group">
            <label for="postTopic">What do you want to post about?</label>
            <input type="text" id="postTopic" placeholder="e.g., promotion, AI project launch, certification, conference insights, research breakthrough">
        </div>
        
        <div class="form-group">
            <label for="postDetails">Provide details:</label>
            <textarea id="postDetails" placeholder="Examples:
• My recent promotion to Senior ML Engineer at Google
• Launched an LLM-powered chatbot that increased customer satisfaction by 45%
• Completed AWS Machine Learning Specialty certification
• Key insights from attending NeurIPS conference in Mumbai
• Published research on transformer optimization techniques"></textarea>
        </div>
        
        <div class="form-group">
            <label for="postTone">Tone:</label>
            <select id="postTone">
                <option value="professional">Professional</option>
                <option value="casual">Casual</option>
                <option value="inspirational">Inspirational</option>
                <option value="thought-leadership">Thought Leadership</option>
            </select>
        </div>
        
        <button id="analyzeTrendsBtn" class="btn">🔍 Analyze Trending Content</button>
        <button id="createPostBtn" class="btn">📝 Create Post</button>
        
        <div id="trendsResult" class="result-section hidden">
            <h4>📊 Trending Content Analysis:</h4>
            <div id="trendsContent"></div>
        </div>
        
        <div id="postResult" class="result-section hidden">
            <h4>📝 Your Optimized Post:</h4>
            <div id="postContent"></div>
            <button id="copyPostBtn" class="btn btn-secondary">📋 Copy Post</button>
        </div>
    </div>

    <!-- Job Search Feature -->
    <div id="jobSearchSection" class="feature-section">
        <div class="feature-title">🔍 Smart Job Search</div>
        
        <!-- Quick Job Search Examples -->
        <div style="margin-bottom: 15px;">
            <div style="font-weight: 500; margin-bottom: 8px; color: #333;">💼 Popular Searches:</div>
            <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                <button class="quick-use-case" onclick="fillJobExample('ml-bangalore')">🤖 ML Bangalore</button>
                <button class="quick-use-case" onclick="fillJobExample('remote-ds')">🌐 Remote DS</button>
                <button class="quick-use-case" onclick="fillJobExample('ai-research')">🔬 AI Research</button>
                <button class="quick-use-case" onclick="fillJobExample('llm-engineer')">🧠 LLM Engineer</button>
                <button class="quick-use-case" onclick="fillJobExample('fintech-pm')">💰 Fintech PM</button>
                <button class="quick-use-case" onclick="fillJobExample('startup-swe')">🚀 Startup SWE</button>
                <button class="quick-use-case" onclick="fillJobExample('devops-mumbai')">⚙️ DevOps Mumbai</button>
                <button class="quick-use-case" onclick="fillJobExample('blockchain')">⛓️ Blockchain</button>
            </div>
        </div>
        
        <div class="form-group">
            <label for="jobQuery">Job Search Query:</label>
            <input type="text" id="jobQuery" placeholder="Examples: ML engineer in Bangalore, AI researcher at startups, remote data scientist, LLM engineer, product manager fintech Mumbai">
        </div>
        
        <button id="searchJobsBtn" class="btn">🔍 Search Jobs</button>
        
        <div id="jobsResult" class="result-section hidden">
            <h4>💼 Job Opportunities:</h4>
            <div id="jobsContent"></div>
        </div>
    </div>

    <!-- Profile Insights Feature -->
    <div id="profileInsightsSection" class="feature-section">
        <div class="feature-title">🎯 Profile Insights</div>
        
        <button id="analyzeProfileBtn" class="btn">📊 Analyze Current Profile</button>
        
        <div id="profileResult" class="result-section hidden">
            <h4>📈 Profile Analysis:</h4>
            <div id="profileContent"></div>
        </div>
    </div>

    <!-- Career Roadmap Feature -->
    <div id="careerRoadmapSection" class="feature-section">
        <div class="feature-title">🗺️ Career Roadmap</div>
        
        <!-- Quick Roadmap Options -->
        <div style="margin-bottom: 15px;">
            <div style="font-weight: 500; margin-bottom: 8px; color: #333;">🚀 Popular Roadmaps:</div>
            <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                <button class="quick-use-case" onclick="fillRoadmapExample('ai-ml')">🤖 AI/ML Career</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('data-science')">📊 Data Science</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('product-mgmt')">📱 Product Mgmt</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('devops')">⚙️ DevOps</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('blockchain')">⛓️ Blockchain</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('cybersecurity')">🛡️ Cybersecurity</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('leadership')">👥 Tech Leadership</button>
                <button class="quick-use-case" onclick="fillRoadmapExample('startup')">🚀 Entrepreneur</button>
            </div>
        </div>
        
        <div class="form-group">
            <label for="careerGoal">Career Goal/Domain:</label>
            <input type="text" id="careerGoal" placeholder="e.g., ML Engineer, Data Scientist, Product Manager, Tech Lead">
        </div>
        
        <div class="form-group">
            <label for="currentLevel">Current Experience Level:</label>
            <select id="currentLevel">
                <option value="entry">Entry Level (0-2 years)</option>
                <option value="mid">Mid Level (2-5 years)</option>
                <option value="senior">Senior Level (5-8 years)</option>
                <option value="lead">Lead/Principal (8+ years)</option>
            </select>
        </div>
        
        <button id="generateRoadmapBtn" class="btn">🗺️ Generate Career Roadmap</button>
        
        <div id="roadmapResult" class="result-section hidden">
            <h4>🗺️ Your Personalized Career Roadmap:</h4>
            <div id="roadmapContent"></div>
        </div>
    </div>

    <!-- Discussion Forum Feature -->
    <div id="forumSection" class="feature-section">
        <div class="feature-title">💬 Tech Discussion Forum</div>
        
        <!-- Quick Discussion Topics -->
        <div style="margin-bottom: 15px;">
            <div style="font-weight: 500; margin-bottom: 8px; color: #333;">🔥 Popular Topics:</div>
            <div style="display: flex; flex-wrap: wrap; gap: 5px;">
                <button class="quick-use-case" onclick="fillForumExample('llm-optimization')">🧠 LLM Optimization</button>
                <button class="quick-use-case" onclick="fillForumExample('career-switch')">🔄 Career Switch</button>
                <button class="quick-use-case" onclick="fillForumExample('startup-advice')">💡 Startup Advice</button>
                <button class="quick-use-case" onclick="fillForumExample('ml-deployment')">🚀 ML Deployment</button>
                <button class="quick-use-case" onclick="fillForumExample('interview-prep')">📝 Interview Prep</button>
                <button class="quick-use-case" onclick="fillForumExample('tech-stack')">⚙️ Tech Stack</button>
                <button class="quick-use-case" onclick="fillForumExample('work-life')">⚖️ Work-Life</button>
                <button class="quick-use-case" onclick="fillForumExample('salary-negotiation')">💰 Salary Tips</button>
            </div>
        </div>
        
        <div class="form-group">
            <label for="discussionTopic">Discussion Topic:</label>
            <input type="text" id="discussionTopic" placeholder="e.g., Best practices for LLM fine-tuning, Career advice for transitioning to AI">
        </div>
        
        <div class="form-group">
            <label for="discussionDetails">Your Question/Discussion Point:</label>
            <textarea id="discussionDetails" placeholder="Describe your question, challenge, or topic you'd like to discuss with the community..."></textarea>
        </div>
        
        <div class="form-group">
            <label for="discussionCategory">Category:</label>
            <select id="discussionCategory">
                <option value="technical">Technical Discussion</option>
                <option value="career">Career Advice</option>
                <option value="industry">Industry Insights</option>
                <option value="tools">Tools & Technologies</option>
                <option value="startup">Startup & Entrepreneurship</option>
                <option value="learning">Learning & Development</option>
                <option value="networking">Networking & Events</option>
                <option value="general">General Discussion</option>
            </select>
        </div>
        
        <button id="createDiscussionBtn" class="btn">💬 Create Discussion Post</button>
        <button id="findExpertBtn" class="btn btn-secondary">🔍 Find Domain Experts</button>
        
        <div id="discussionResult" class="result-section hidden">
            <h4>💬 Your Discussion Post:</h4>
            <div id="discussionContent"></div>
        </div>
        
        <div id="expertResult" class="result-section hidden">
            <h4>👥 Relevant Experts & Communities:</h4>
            <div id="expertContent"></div>
        </div>
    </div>

    <script>
        // Assistant JavaScript functionality
        class LinkedInAssistant {
            constructor() {
                this.init();
            }

            init() {
                this.bindEvents();
            }

            bindEvents() {
                document.getElementById('analyzeTrendsBtn').addEventListener('click', () => this.analyzeTrends());
                document.getElementById('createPostBtn').addEventListener('click', () => this.createPost());
                document.getElementById('copyPostBtn').addEventListener('click', () => this.copyPost());
                document.getElementById('searchJobsBtn').addEventListener('click', () => this.searchJobs());
                document.getElementById('analyzeProfileBtn').addEventListener('click', () => this.analyzeProfile());
                document.getElementById('generateRoadmapBtn').addEventListener('click', () => this.generateRoadmap());
                document.getElementById('createDiscussionBtn').addEventListener('click', () => this.createDiscussion());
                document.getElementById('findExpertBtn').addEventListener('click', () => this.findExperts());
                
                // Make functions globally available for onclick handlers
                window.fillPostExample = this.fillPostExample.bind(this);
                window.fillJobExample = this.fillJobExample.bind(this);
                window.fillRoadmapExample = this.fillRoadmapExample.bind(this);
                window.fillForumExample = this.fillForumExample.bind(this);
            }

            fillPostExample(type) {
                const examples = {
                    'promotion': {
                        topic: 'Recent promotion to Senior ML Engineer',
                        details: 'I am excited to share that I have been promoted to Senior ML Engineer at TechCorp India! This new role involves leading the AI research team and developing next-generation LLM applications. Looking forward to the challenges ahead and contributing to cutting-edge AI innovations.'
                    },
                    'project': {
                        topic: 'Launched AI-powered customer service chatbot',
                        details: 'Our team successfully launched an LLM-powered customer service chatbot that reduced response times by 60% and increased customer satisfaction scores by 45%. Built using transformers and deployed on AWS, handling 10k+ queries daily.'
                    },
                    'certification': {
                        topic: 'Completed AWS Machine Learning Specialty certification',
                        details: 'Proud to announce that I have earned the AWS Machine Learning Specialty certification! This intensive study period covered everything from data engineering to model deployment. Excited to apply these cloud ML skills in upcoming projects.'
                    },
                    'conference': {
                        topic: 'Key insights from NeurIPS conference in Mumbai',
                        details: 'Just returned from an incredible NeurIPS conference in Mumbai. Key takeaways: 1) Multimodal AI is the future, 2) Efficiency in large models is critical, 3) Indian AI research is world-class. Met amazing researchers and came back inspired!'
                    },
                    'research': {
                        topic: 'Published research on transformer optimization',
                        details: 'Thrilled to share that our paper "Efficient Attention Mechanisms for Large Language Models" has been accepted at ICML 2024! Our novel approach reduces computational costs by 35% while maintaining performance. Grateful to my amazing co-authors.'
                    },
                    'startup': {
                        topic: 'Our AI startup reached 1M users milestone',
                        details: 'Incredible milestone! Our AI-powered language learning app just hit 1 million active users. From a small team of 3 engineers in Bangalore to impacting learners globally. The journey of building scalable AI products continues!'
                    },
                    'mentoring': {
                        topic: 'Mentoring junior developers in AI/ML',
                        details: 'Spent the weekend mentoring 20 junior developers at the Bangalore ML bootcamp. Their enthusiasm for AI and fresh perspectives were inspiring. Remember: the best way to learn is to teach. Always happy to give back to the community!'
                    },
                    'insights': {
                        topic: 'The future of LLMs in Indian languages',
                        details: 'Fascinating to see the progress in Indic language LLMs. Models like AI4Bharat are democratizing AI for 1.3B+ people. The intersection of cultural context and AI opens up incredible opportunities for inclusive technology development.'
                    }
                };
                
                const example = examples[type];
                if (example) {
                    document.getElementById('postTopic').value = example.topic;
                    document.getElementById('postDetails').value = example.details;
                }
            }

            fillJobExample(type) {
                const examples = {
                    'ml-bangalore': 'Machine Learning Engineer jobs in Bangalore India',
                    'remote-ds': 'Remote Data Scientist positions',
                    'ai-research': 'AI Researcher roles at top tech companies',
                    'llm-engineer': 'LLM Engineer positions at AI startups',
                    'fintech-pm': 'Product Manager roles in fintech companies Mumbai',
                    'startup-swe': 'Software Engineer jobs at early-stage startups',
                    'devops-mumbai': 'DevOps Engineer positions in Mumbai',
                    'blockchain': 'Blockchain Developer remote opportunities'
                };
                
                const example = examples[type];
                if (example) {
                    document.getElementById('jobQuery').value = example;
                }
            }

            fillRoadmapExample(type) {
                const examples = {
                    'ai-ml': {
                        goal: 'Senior Machine Learning Engineer',
                        level: 'mid'
                    },
                    'data-science': {
                        goal: 'Senior Data Scientist',
                        level: 'mid'
                    },
                    'product-mgmt': {
                        goal: 'Senior Product Manager',
                        level: 'mid'
                    },
                    'devops': {
                        goal: 'DevOps Lead',
                        level: 'senior'
                    },
                    'blockchain': {
                        goal: 'Blockchain Architect',
                        level: 'senior'
                    },
                    'cybersecurity': {
                        goal: 'Security Architect',
                        level: 'senior'
                    },
                    'leadership': {
                        goal: 'Engineering Manager',
                        level: 'lead'
                    },
                    'startup': {
                        goal: 'Tech Startup Founder',
                        level: 'senior'
                    }
                };
                
                const example = examples[type];
                if (example) {
                    document.getElementById('careerGoal').value = example.goal;
                    document.getElementById('currentLevel').value = example.level;
                }
            }

            fillForumExample(type) {
                const examples = {
                    'llm-optimization': {
                        topic: 'Best practices for optimizing LLM inference speed',
                        details: 'I\'m working on optimizing our LLM-powered chatbot for production. Currently, response times are around 2-3 seconds, but I need to get them under 1 second. What are the best techniques for LLM optimization? I\'ve tried quantization and pruning, but looking for more advanced strategies.',
                        category: 'technical'
                    },
                    'career-switch': {
                        topic: 'Transitioning from software engineering to ML engineering',
                        details: 'I\'m a software engineer with 4 years of experience in backend development (Python, Go, microservices). I want to transition into ML engineering. What skills should I focus on? Should I get a Masters or are online courses sufficient? Any advice on making this transition in the Indian job market?',
                        category: 'career'
                    },
                    'startup-advice': {
                        topic: 'Building an AI startup in India - fundraising tips',
                        details: 'I\'m building an AI-powered EdTech startup targeting Indian regional languages. We have a working MVP and some early users. Looking for advice on fundraising in India - which VCs to approach, what metrics to focus on, and how to position an AI startup in the current market.',
                        category: 'startup'
                    },
                    'ml-deployment': {
                        topic: 'MLOps best practices for model deployment at scale',
                        details: 'Our team is deploying ML models for a fintech company serving 10M+ users. We\'re struggling with model versioning, A/B testing, and monitoring in production. What are the industry best practices for MLOps? Which tools and platforms work best for Indian companies?',
                        category: 'technical'
                    },
                    'interview-prep': {
                        topic: 'Machine Learning interview preparation for FAANG companies',
                        details: 'I\'m preparing for ML engineer interviews at Google, Meta, and Microsoft. What should I focus on? System design for ML, coding problems, or theoretical concepts? Any specific resources or mock interview platforms you\'d recommend? Also, how different are Indian offices vs US offices?',
                        category: 'career'
                    },
                    'tech-stack': {
                        topic: 'Choosing between PyTorch and TensorFlow for production',
                        details: 'We\'re building a computer vision pipeline for a retail company. Debating between PyTorch and TensorFlow for production deployment. Our team is more familiar with PyTorch, but TensorFlow seems to have better deployment tools. What would you recommend and why?',
                        category: 'tools'
                    },
                    'work-life': {
                        topic: 'Managing work-life balance in the Indian tech industry',
                        details: 'Working at a fast-growing startup in Bangalore. The work is exciting but the hours are long (often 10-12 hours). How do other tech professionals in India manage work-life balance? Any tips for setting boundaries while still advancing your career?',
                        category: 'general'
                    },
                    'salary-negotiation': {
                        topic: 'Salary negotiation strategies for senior roles in India',
                        details: 'I\'m interviewing for Senior ML Engineer roles in Bangalore and Mumbai. The salary ranges vary widely (25L to 45L). How do you effectively negotiate salary in the Indian market? What factors beyond base salary should I consider? Stock options, learning opportunities, etc.?',
                        category: 'career'
                    }
                };
                
                const example = examples[type];
                if (example) {
                    document.getElementById('discussionTopic').value = example.topic;
                    document.getElementById('discussionDetails').value = example.details;
                    document.getElementById('discussionCategory').value = example.category;
                }
            }

            async analyzeTrends() {
                const topic = document.getElementById('postTopic').value.trim();
                if (!topic) {
                    alert('Please enter a topic first');
                    return;
                }

                this.showLoading('trendsResult');
                
                try {
                    const response = await chrome.runtime.sendMessage({
                        action: 'analyzeTrendingPosts',
                        topic: topic
                    });

                    if (response.success) {
                        this.displayTrends(response.trends);
                    } else {
                        throw new Error(response.error);
                    }
                } catch (error) {
                    this.showError('trendsResult', 'Failed to analyze trends: ' + error.message);
                }
            }

            async createPost() {
                const topic = document.getElementById('postTopic').value.trim();
                const details = document.getElementById('postDetails').value.trim();
                const tone = document.getElementById('postTone').value;

                if (!topic || !details) {
                    alert('Please fill in topic and details');
                    return;
                }

                this.showLoading('postResult');

                try {
                    const response = await chrome.runtime.sendMessage({
                        action: 'optimizePost',
                        content: { topic, details, tone },
                        trends: this.currentTrends
                    });

                    if (response.success) {
                        this.displayPost(response.post);
                    } else {
                        throw new Error(response.error);
                    }
                } catch (error) {
                    this.showError('postResult', 'Failed to create post: ' + error.message);
                }
            }

            async searchJobs() {
                const query = document.getElementById('jobQuery').value.trim();
                if (!query) {
                    alert('Please enter a job search query');
                    return;
                }

                this.showLoading('jobsResult');

                try {
                    const response = await chrome.runtime.sendMessage({
                        action: 'searchJobs',
                        query: query
                    });

                    if (response.success) {
                        this.displayJobs(response.jobs);
                    } else {
                        throw new Error(response.error);
                    }
                } catch (error) {
                    this.showError('jobsResult', 'Failed to search jobs: ' + error.message);
                }
            }

            async analyzeProfile() {
                this.showLoading('profileResult');

                try {
                    // Extract current LinkedIn profile data
                    const profileData = this.extractLinkedInProfile();
                    
                    const response = await chrome.runtime.sendMessage({
                        action: 'analyzeProfile',
                        profileData: profileData
                    });

                    if (response.success) {
                        this.displayProfileInsights(response.insights);
                    } else {
                        throw new Error(response.error);
                    }
                } catch (error) {
                    this.showError('profileResult', 'Failed to analyze profile: ' + error.message);
                }
            }

            extractLinkedInProfile() {
                // Extract profile data from current LinkedIn page
                const profile = {};
                
                // Try to extract from various LinkedIn page types
                const nameEl = document.querySelector('h1.text-heading-xlarge, .pv-text-details__left-panel h1');
                if (nameEl) profile.name = nameEl.textContent.trim();

                const headlineEl = document.querySelector('.text-body-medium.break-words, .pv-text-details__left-panel .text-body-medium');
                if (headlineEl) profile.headline = headlineEl.textContent.trim();

                const locationEl = document.querySelector('.text-body-small.inline.t-black--light, .pv-text-details__left-panel .pb2');
                if (locationEl) profile.location = locationEl.textContent.trim();

                return profile;
            }

            displayTrends(trends) {
                const content = document.getElementById('trendsContent');
                this.currentTrends = trends;
                
                content.innerHTML = trends.map(trend => 
                    '<div class="trend-item">' +
                    '<strong>' + trend.title + '</strong><br>' +
                    '<small>' + trend.engagement + ' engagement</small><br>' +
                    '<div>' + trend.hashtags.map(tag => '<span class="hashtag">' + tag + '</span>').join('') + '</div>' +
                    '</div>'
                ).join('');
                
                document.getElementById('trendsResult').classList.remove('hidden');
            }

            displayPost(post) {
                const content = document.getElementById('postContent');
                content.innerHTML = 
                    '<div style="white-space: pre-wrap; background: white; padding: 15px; border-radius: 6px; border: 1px solid #ddd;">' +
                    post.content +
                    '</div>' +
                    '<div style="margin-top: 10px;"><strong>Suggested hashtags:</strong> ' +
                    post.hashtags.map(tag => '<span class="hashtag">' + tag + '</span>').join('') +
                    '</div>';
                
                this.currentPost = post.content;
                document.getElementById('postResult').classList.remove('hidden');
            }

            displayJobs(jobs) {
                const content = document.getElementById('jobsContent');
                content.innerHTML = jobs.map(job =>
                    '<div class="job-item">' +
                    '<div class="job-title">' + job.title + '</div>' +
                    '<div class="job-company">' + job.company + ' • ' + job.location + '</div>' +
                    '<div style="margin-top: 10px;"><small>' + job.match_analysis + '</small></div>' +
                    '<div style="margin-top: 10px;">' +
                    '<a href="' + job.linkedin_url + '" target="_blank" style="color: #0077b5;">View Job</a>' +
                    (job.apply_url ? ' • <a href="' + job.apply_url + '" target="_blank" style="color: #0077b5;">Apply Direct</a>' : '') +
                    '</div>' +
                    '</div>'
                ).join('');
                
                document.getElementById('jobsResult').classList.remove('hidden');
            }

            displayProfileInsights(insights) {
                const content = document.getElementById('profileContent');
                content.innerHTML = 
                    '<div style="background: white; padding: 15px; border-radius: 6px; border: 1px solid #ddd;">' +
                    insights.analysis +
                    '</div>';
                
                document.getElementById('profileResult').classList.remove('hidden');
            }

            copyPost() {
                if (this.currentPost) {
                    navigator.clipboard.writeText(this.currentPost);
                    alert('Post copied to clipboard!');
                }
            }

            showLoading(sectionId) {
                const section = document.getElementById(sectionId);
                section.innerHTML = '<div class="loading">⏳ Processing...</div>';
                section.classList.remove('hidden');
            }

            showError(sectionId, message) {
                const section = document.getElementById(sectionId);
                section.innerHTML = '<div style="color: #d32f2f;">❌ ' + message + '</div>';
                section.classList.remove('hidden');
            }
        }

        // Initialize assistant
        new LinkedInAssistant();
    </script>
</body>
</html>
        `;
    }

    closeAssistant() {
        if (this.assistantContainer) {
            this.assistantContainer.style.display = 'none';
        }
    }

    extractCurrentProfileData() {
        const profile = {};
        
        // Extract name
        const nameEl = document.querySelector('h1.text-heading-xlarge, .pv-text-details__left-panel h1');
        if (nameEl) profile.name = nameEl.textContent.trim();

        // Extract headline
        const headlineEl = document.querySelector('.text-body-medium.break-words, .pv-text-details__left-panel .text-body-medium');
        if (headlineEl) profile.headline = headlineEl.textContent.trim();

        // Extract location
        const locationEl = document.querySelector('.text-body-small.inline.t-black--light, .pv-text-details__left-panel .pb2');
        if (locationEl) profile.location = locationEl.textContent.trim();

        // Extract profile picture
        const avatarEl = document.querySelector('.pv-top-card__photo, .presence-entity__image');
        if (avatarEl) profile.profilePicture = avatarEl.src;
        
        // Extract LinkedIn URL/ID
        const profilePath = window.location.pathname;
        if (profilePath.includes('/in/')) {
            const linkedinId = profilePath.split('/in/')[1].split('/')[0];
            profile.linkedinId = linkedinId;
        }
        
        // Extract experience
        const experiences = [];
        const experienceSection = document.getElementById('experience-section') || 
            document.querySelector('.experience-section');
            
        if (experienceSection) {
            const experienceItems = experienceSection.querySelectorAll('li.pv-entity__position-group-pager, .pvs-list__paged-list-item');
            experienceItems.forEach(item => {
                const titleEl = item.querySelector('.pv-entity__summary-info h3, .pv-entity__summary-info-margin-top h3, .t-16.t-black.t-bold');
                const companyEl = item.querySelector('.pv-entity__secondary-title, .t-14.t-black.t-normal');
                const dateRangeEl = item.querySelector('.pv-entity__date-range span:nth-child(2), .t-14.t-normal.t-black--light span:not(:first-child)');
                
                if (titleEl) {
                    const experience = {
                        title: titleEl.textContent.trim(),
                        company: companyEl ? companyEl.textContent.trim() : '',
                        dateRange: dateRangeEl ? dateRangeEl.textContent.trim() : ''
                    };
                    experiences.push(experience);
                }
            });
        }
        profile.experiences = experiences;
        
        // Extract skills
        const skills = [];
        const skillsSection = document.getElementById('skills-section') || 
            document.querySelector('.pv-skill-categories-section');
            
        if (skillsSection) {
            const skillItems = skillsSection.querySelectorAll('.pv-skill-category-entity__name-text, .pv-skill-entity__skill-name');
            skillItems.forEach(item => {
                skills.push(item.textContent.trim());
            });
        }
        profile.skills = skills;
        
        // Extract latest post if on activity page
        if (window.location.pathname.includes('/detail/recent-activity/')) {
            const latestPostEl = document.querySelector('.feed-shared-update-v2__description');
            if (latestPostEl) {
                profile.latestPost = latestPostEl.textContent.trim();
            }
        }

        return profile;
    }

    extractPostData() {
        // Extract data from LinkedIn posts for analysis
        const posts = [];
        const postElements = document.querySelectorAll('[data-id^="urn:li:activity:"], [data-urn^="urn:li:activity:"]');
        
        postElements.forEach(postEl => {
            const contentEl = postEl.querySelector('.break-words span[dir="ltr"], .feed-shared-update-v2__description');
            const authorEl = postEl.querySelector('.update-components-actor__name, .feed-shared-actor__name');
            const authorTitleEl = postEl.querySelector('.update-components-actor__description, .feed-shared-actor__description');
            
            // Extract engagement metrics
            const likesEl = postEl.querySelector('.social-details-social-counts__reactions-count, .social-details-social-counts__count-value');
            const commentsEl = postEl.querySelector('.comments-button__count span');
            const sharesEl = postEl.querySelector('.feed-shared-social-counts__num-shares');
            
            // Extract timestamp
            const timestampEl = postEl.querySelector('.feed-shared-actor__sub-description, .update-components-actor__sub-description');
            
            // Extract post URL
            let postUrl = '';
            const linkToPostEl = postEl.querySelector('.feed-shared-control-menu__trigger');
            if (linkToPostEl) {
                const dataId = postEl.getAttribute('data-id') || postEl.getAttribute('data-urn');
                if (dataId) {
                    const activityId = dataId.replace('urn:li:activity:', '');
                    postUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${activityId}`;
                }
            }
            
            // Extract hashtags
            const hashtags = [];
            if (contentEl) {
                const contentText = contentEl.textContent.trim();
                const hashtagMatches = contentText.match(/#[\w-]+/g);
                if (hashtagMatches) {
                    hashtags.push(...hashtagMatches);
                }
            }
            
            if (contentEl && authorEl) {
                posts.push({
                    content: contentEl.textContent.trim(),
                    author: authorEl.textContent.trim(),
                    authorTitle: authorTitleEl ? authorTitleEl.textContent.trim() : '',
                    likes: likesEl ? parseInt(likesEl.textContent.trim().replace(/,/g, '')) || 0 : 0,
                    comments: commentsEl ? parseInt(commentsEl.textContent.trim().replace(/,/g, '')) || 0 : 0,
                    shares: sharesEl ? parseInt(sharesEl.textContent.trim().replace(/,/g, '')) || 0 : 0,
                    timestamp: timestampEl ? timestampEl.textContent.trim() : '',
                    postUrl: postUrl,
                    hashtags: hashtags
                });
            }
        });

        return posts;
    }
}

// Initialize content script
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new LinkedInAssistantContent());
} else {
    new LinkedInAssistantContent();
}
