#!/usr/bin/env python3

import sys
import os

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def handle_discussion_forum(usermessage):
    """
    Handle discussion forum requests by asking for confirmation before redirecting 
    to the LinkedIn Forums AI platform.
    """
    
    return {
        'message': f"🗣️ **Perfect! This is a great topic for community discussion.**\n\n"
                  f"I think this would be ideal for our **LinkedIn Forums AI** platform where you can:\n\n"
                  f"💬 **Engage with professionals** in meaningful discussions\n"
                  f"🧠 **Get diverse perspectives** from industry experts\n"
                  f"🤝 **Build connections** through thoughtful conversations\n"
                  f"📈 **Share insights** and learn from the community\n\n"
                  f"**Would you like me to redirect you to the LinkedIn Forums AI platform?**\n\n"
                  f"Please respond with:\n"
                  f"• **Yes** - Take me to the forums\n"
                  f"• **No** - Continue our conversation here\n\n"
                  f"� *The forums are specifically designed for professional discussions like yours!*",
        'data': {
            'type': 'forum_confirmation',
            'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
            'action': 'ask_forum_confirmation',
            'original_message': usermessage,
            'awaiting_confirmation': True
        }
    }

def handle_forum_confirmation(user_message):
    """
    Handle yes/no response for forum redirection confirmation
    """
    message_lower = user_message.lower().strip()
    
    # Check for positive responses
    if any(word in message_lower for word in ['yes', 'y', 'ok', 'okay', 'sure', 'take me', 'redirect', 'forums']):
        return {
            'message': f"🚀 **Excellent! Redirecting you to LinkedIn Forums AI...**\n\n"
                      f"You'll be taken to our specialized discussion platform where you can:\n\n"
                      f"💬 Connect with professionals\n"
                      f"🤝 Share your insights\n"
                      f"📈 Learn from the community\n\n"
                      f"**[🔗 Click here to access LinkedIn Forums AI](https://linked-in-forums-ai-54.lovable.app)**\n\n"
                      f"Enjoy your discussion! 🎉",
            'data': {
                'type': 'forum_redirect',
                'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
                'action': 'confirmed_redirect',
                'confirmed': True
            }
        }
    
    # Check for negative responses
    elif any(word in message_lower for word in ['no', 'n', 'nope', 'continue', 'stay', 'here']):
        return {
            'message': f"👍 **No problem! Let's continue our conversation here.**\n\n"
                      f"I'm happy to help you with your question. How can I assist you further?\n\n"
                      f"I can help with:\n"
                      f"📝 **Content Creation** - LinkedIn posts and professional content\n"
                      f"🔍 **Job Search** - Finding opportunities and career advice\n"
                      f"👥 **Referrals** - Connecting you with professionals\n"
                      f"📊 **Post Analysis** - Analyzing your LinkedIn content\n\n"
                      f"What would you like to explore?",
            'data': {
                'type': 'continue_conversation',
                'action': 'declined_redirect',
                'confirmed': False
            }
        }
    
    # Unclear response - ask again
    else:
        return {
            'message': f"🤔 **I didn't quite catch that.**\n\n"
                      f"Would you like me to redirect you to the LinkedIn Forums AI platform for community discussion?\n\n"
                      f"Please respond with:\n"
                      f"• **Yes** or **Y** - Take me to the forums\n"
                      f"• **No** or **N** - Continue here\n\n"
                      f"💡 *Just type 'yes' or 'no' to let me know!*",
            'data': {
                'type': 'forum_confirmation',
                'redirect_url': 'https://linked-in-forums-ai-54.lovable.app',
                'action': 'ask_forum_confirmation',
                'awaiting_confirmation': True
            }
        }

if __name__ == "__main__":
    print("Testing handle_discussion_forum function with confirmation flow...")
    print("=" * 70)
    
    # Test initial forum request
    test_message = "What do you think about remote work trends?"
    print(f"1. Initial forum question: \"{test_message}\"")
    result = handle_discussion_forum(test_message)
    print(f"Response: {result['message'][:100]}...")
    print(f"Action: {result['data']['action']}")
    print(f"Awaiting confirmation: {result['data']['awaiting_confirmation']}")
    print("-" * 50)
    
    # Test YES response
    print("2. User responds with 'Yes'")
    yes_result = handle_forum_confirmation("Yes")
    print(f"Response: {yes_result['message'][:100]}...")
    print(f"Redirect URL: {yes_result['data']['redirect_url']}")
    print(f"Action: {yes_result['data']['action']}")
    print(f"Confirmed: {yes_result['data']['confirmed']}")
    print("-" * 50)
    
    # Test NO response
    print("3. User responds with 'No'")
    no_result = handle_forum_confirmation("No")
    print(f"Response: {no_result['message'][:100]}...")
    print(f"Action: {no_result['data']['action']}")
    print(f"Confirmed: {no_result['data']['confirmed']}")
    print("-" * 50)
    
    # Test unclear response
    print("4. User responds with unclear answer")
    unclear_result = handle_forum_confirmation("maybe")
    print(f"Response: {unclear_result['message'][:100]}...")
    print(f"Action: {unclear_result['data']['action']}")
    print(f"Awaiting confirmation: {unclear_result['data']['awaiting_confirmation']}")
    print("-" * 50)
